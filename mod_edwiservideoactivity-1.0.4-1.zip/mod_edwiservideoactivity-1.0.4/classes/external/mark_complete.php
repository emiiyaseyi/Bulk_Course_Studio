<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Trait for marking video activity as complete.
 *
 * @package    mod_edwiservideoactivity
 * @copyright  2025 Edwiser
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_edwiservideoactivity\external;

use completion_info;
use context_module;
use external_function_parameters;
use external_single_structure;
use external_value;

/**
 * Trait implementing the mark_complete external function.
 */
trait mark_complete {
    /**
     * Returns description of method parameters.
     *
     * @return external_function_parameters
     */
    public static function mark_complete_parameters() {
        return new external_function_parameters([
            'cmid' => new external_value(PARAM_INT, 'Course module ID'),
        ]);
    }

    /**
     * Mark video activity as complete for a user.
     *
     * @param int $cmid Course module ID
     * @return array Response data
     */
    public static function mark_complete($cmid) {
        global $USER;

        // Validate parameters.
        $params = self::validate_parameters(self::mark_complete_parameters(), [
            'cmid' => $cmid,
        ]);

        // Validate course module.
        $cm = get_coursemodule_from_id('edwiservideoactivity', $params['cmid'], 0, false, MUST_EXIST);
        $context = context_module::instance($params['cmid']);
        self::validate_context($context);
        require_capability('mod/edwiservideoactivity:view', $context);

        // Get course and completion.
        $course = get_course($cm->course);
        $completion = new completion_info($course);

        // Check if completion is enabled for this activity.
        if ($completion->is_enabled($cm)) {
            // Mark activity as complete.
            $completion->update_state($cm, COMPLETION_COMPLETE, $USER->id);

            return [
                'success' => true,
                'message' => get_string('activitycompleted', 'mod_edwiservideoactivity'),
            ];
        }

        return [
            'success' => false,
            'message' => get_string('completionnotenabled', 'mod_edwiservideoactivity'),
        ];
    }

    /**
     * Returns description of method result value.
     *
     * @return external_single_structure
     */
    public static function mark_complete_returns() {
        return new external_single_structure([
            'success' => new external_value(PARAM_BOOL, 'Whether the operation was successful'),
            'message' => new external_value(PARAM_TEXT, 'Status message'),
        ]);
    }
}

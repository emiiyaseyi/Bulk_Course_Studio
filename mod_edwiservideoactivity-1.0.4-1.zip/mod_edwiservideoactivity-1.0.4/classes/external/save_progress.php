<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Trait for saving video progress.
 *
 * @package    mod_edwiservideoactivity
 * @copyright  2025 Edwiser
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_edwiservideoactivity\external;

use context_module;
use external_function_parameters;
use external_single_structure;
use external_value;

/**
 * Trait implementing the save_progress external function.
 */
trait save_progress {
    /**
     * Returns description of method parameters.
     *
     * @return external_function_parameters
     */
    public static function save_progress_parameters() {
        return new external_function_parameters([
            'cmid' => new external_value(PARAM_INT, 'Course module ID'),
            'currenttime' => new external_value(PARAM_INT, 'Current playback time in seconds'),
            'duration' => new external_value(PARAM_INT, 'Total video duration in seconds'),
            'percent' => new external_value(PARAM_INT, 'Progress percentage (0-100)'),
            'provider' => new external_value(PARAM_ALPHANUMEXT, 'Video provider (html5, youtube, vimeo, loom)'),
        ]);
    }

    /**
     * Save video progress for a user.
     *
     * @param int $cmid Course module ID
     * @param int $currenttime Current playback time in seconds
     * @param int $duration Total video duration in seconds
     * @param int $percent Progress percentage (0-100)
     * @param string $provider Video provider
     * @return array Response data
     */
    public static function save_progress($cmid, $currenttime, $duration, $percent, $provider) {
        global $DB, $USER;

        // Validate parameters.
        $params = self::validate_parameters(self::save_progress_parameters(), [
            'cmid' => $cmid,
            'currenttime' => $currenttime,
            'duration' => $duration,
            'percent' => $percent,
            'provider' => $provider,
        ]);

        // Validate course module.
        $cm = get_coursemodule_from_id('edwiservideoactivity', $params['cmid'], 0, false, MUST_EXIST);
        $context = context_module::instance($params['cmid']);
        self::validate_context($context);
        require_capability('mod/edwiservideoactivity:view', $context);

        // Get activity instance to determine sourcetype.
        $activity = $DB->get_record('edwiservideoactivity', ['id' => $cm->instance], '*', MUST_EXIST);

        // Get or create progress record.
        $progress = $DB->get_record('edwiservideoactivity_progress', [
            'cm_id' => $params['cmid'],
            'user_id' => $USER->id,
        ]);

        $now = time();

        // Get properly quoted column name using Moodle's DDL generator for reserved keywords.
        $generator = $DB->get_manager()->generator;
        $quotedpercent = $generator->getEncQuoted('percent');

        if ($progress) {
            // Update existing record using raw SQL to handle reserved keywords.
            $sql = "UPDATE {edwiservideoactivity_progress}
                       SET currenttime = :currenttime,
                           duration = :duration,
                           {$quotedpercent} = :percent,
                           provider = :provider,
                           timemodified = :timemodified
                     WHERE cm_id = :cmid AND user_id = :userid";
            $DB->execute($sql, [
                'currenttime' => $params['currenttime'],
                'duration' => $params['duration'],
                'percent' => $params['percent'],
                'provider' => $params['provider'],
                'timemodified' => $now,
                'cmid' => $params['cmid'],
                'userid' => $USER->id,
            ]);
        } else {
            // Create new record using raw SQL to handle reserved keywords.
            $sql = "INSERT INTO {edwiservideoactivity_progress}
                        (cm_id, user_id, currenttime, duration, {$quotedpercent}, videoname, sourcetype, provider,
                         timecreated, timemodified)
                    VALUES (:cmid, :userid, :currenttime, :duration, :percent, :videoname, :sourcetype,
                            :provider, :timecreated, :timemodified)";
            $DB->execute($sql, [
                'cmid' => $params['cmid'],
                'userid' => $USER->id,
                'currenttime' => $params['currenttime'],
                'duration' => $params['duration'],
                'percent' => $params['percent'],
                'videoname' => $cm->name,
                'sourcetype' => $activity->sourcetype,
                'provider' => $params['provider'],
                'timecreated' => $now,
                'timemodified' => $now,
            ]);
        }

        return [
            'success' => true,
            'progress' => $params['percent'],
            'provider' => $params['provider'],
        ];
    }

    /**
     * Returns description of method result value.
     *
     * @return external_single_structure
     */
    public static function save_progress_returns() {
        return new external_single_structure([
            'success' => new external_value(PARAM_BOOL, 'Whether the save was successful'),
            'progress' => new external_value(PARAM_INT, 'Saved progress percentage'),
            'provider' => new external_value(PARAM_ALPHANUMEXT, 'Video provider'),
        ]);
    }
}

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace mod_edwiservideoactivity\privacy;

use core_privacy\local\metadata\collection;
use core_privacy\local\request\approved_contextlist;
use core_privacy\local\request\approved_userlist;
use core_privacy\local\request\contextlist;
use core_privacy\local\request\helper;
use core_privacy\local\request\transform;
use core_privacy\local\request\userlist;
use core_privacy\local\request\writer;

/**
 * Privacy API implementation for the Edwiser Video Activity module.
 *
 * @package    mod_edwiservideoactivity
 * @copyright  2024 Edwiser
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class provider implements
    \core_privacy\local\metadata\provider,
    \core_privacy\local\request\core_userlist_provider,
    \core_privacy\local\request\plugin\provider {
    /**
     * Return the fields which contain personal data.
     *
     * @param collection $collection The initialised collection to add items to.
     * @return collection A listing of user data stored through this system.
     */
    public static function get_metadata(collection $collection): collection {
        $collection->add_database_table('edwiservideoactivity_progress', [
            'user_id' => 'privacy:metadata:progress:user_id',
            'cm_id' => 'privacy:metadata:progress:cm_id',
            'currenttime' => 'privacy:metadata:progress:currenttime',
            'duration' => 'privacy:metadata:progress:duration',
            'percent' => 'privacy:metadata:progress:percent',
            'videoname' => 'privacy:metadata:progress:videoname',
            'sourcetype' => 'privacy:metadata:progress:sourcetype',
            'provider' => 'privacy:metadata:progress:provider',
            'timecreated' => 'privacy:metadata:progress:timecreated',
            'timemodified' => 'privacy:metadata:progress:timemodified',
        ], 'privacy:metadata:progress');

        $collection->add_external_location_link('plyr', [
            'url' => 'privacy:metadata:external:plyr:url',
        ], 'privacy:metadata:external:plyr');

        return $collection;
    }

    /**
     * Get the list of contexts that contain user information for the specified user.
     *
     * @param int $userid The user to search.
     * @return contextlist The contextlist containing the list of contexts used in this plugin.
     */
    public static function get_contexts_for_userid(int $userid): contextlist {
        $sql = "SELECT ctx.id
                  FROM {edwiservideoactivity_progress} p
                  JOIN {context} ctx
                    ON ctx.instanceid = p.cm_id
                   AND ctx.contextlevel = :modlevel
                 WHERE p.user_id = :userid";

        $params = ['modlevel' => CONTEXT_MODULE, 'userid' => $userid];
        $contextlist = new contextlist();
        $contextlist->add_from_sql($sql, $params);

        return $contextlist;
    }

    /**
     * Get the list of users who have data within a context.
     *
     * @param userlist $userlist The userlist containing the list of users who have data in this context/plugin combination.
     */
    public static function get_users_in_context(userlist $userlist) {
        $context = $userlist->get_context();

        if (!is_a($context, \context_module::class)) {
            return;
        }

        $sql = "SELECT p.user_id
                  FROM {edwiservideoactivity_progress} p
                  JOIN {context} ctx
                    ON ctx.instanceid = p.cm_id
                   AND ctx.contextlevel = :modlevel
                 WHERE ctx.id = :contextid";

        $params = ['modlevel' => CONTEXT_MODULE, 'contextid' => $context->id];
        $userlist->add_from_sql('user_id', $sql, $params);
    }

    /**
     * Export all user data for the specified user, in the specified contexts.
     *
     * @param approved_contextlist $contextlist The approved contexts to export information for.
     */
    public static function export_user_data(approved_contextlist $contextlist) {
        global $DB;

        $contexts = array_reduce($contextlist->get_contexts(), function ($carry, $context) {
            if ($context->contextlevel == CONTEXT_MODULE) {
                $carry[] = $context->id;
            }
            return $carry;
        }, []);

        if (empty($contexts)) {
            return;
        }

        $user = $contextlist->get_user();
        $userid = $user->id;

        // Export activity context data.
        foreach ($contexts as $contextid) {
            $context = \context::instance_by_id($contextid);
            $data = helper::get_context_data($context, $user);
            writer::with_context($context)->export_data([], $data);
            helper::export_context_files($context, $user);
        }

        // Export progress data.
        [$insql, $inparams] = $DB->get_in_or_equal($contexts, SQL_PARAMS_NAMED);
        $sql = "SELECT p.id,
                       p.currenttime,
                       p.duration,
                       p.percent,
                       p.videoname,
                       p.sourcetype,
                       p.provider,
                       p.timecreated,
                       p.timemodified,
                       ctx.id AS contextid
                  FROM {edwiservideoactivity_progress} p
                  JOIN {context} ctx
                    ON ctx.instanceid = p.cm_id
                   AND ctx.contextlevel = :modlevel
                 WHERE ctx.id $insql
                   AND p.user_id = :userid";
        $params = array_merge($inparams, ['modlevel' => CONTEXT_MODULE, 'userid' => $userid]);

        $progressrecords = $DB->get_recordset_sql($sql, $params);
        foreach ($progressrecords as $record) {
            $context = \context::instance_by_id($record->contextid);
            $subcontext = [get_string('privacy:progresspath', 'edwiservideoactivity')];
            writer::with_context($context)->export_data($subcontext, (object) [
                'currenttime' => $record->currenttime,
                'duration' => $record->duration,
                'percent' => $record->percent,
                'videoname' => $record->videoname,
                'sourcetype' => $record->sourcetype,
                'provider' => $record->provider,
                'timecreated' => transform::datetime($record->timecreated),
                'timemodified' => transform::datetime($record->timemodified),
            ]);
        }
        $progressrecords->close();
    }

    /**
     * Delete all user data which matches the specified context.
     *
     * @param \context $context A user context.
     */
    public static function delete_data_for_all_users_in_context(\context $context) {
        global $DB;

        if ($context->contextlevel != CONTEXT_MODULE) {
            return;
        }

        $DB->delete_records('edwiservideoactivity_progress', ['cm_id' => $context->instanceid]);
    }

    /**
     * Delete all user data for the specified user, in the specified contexts.
     *
     * @param approved_contextlist $contextlist The approved contexts and user information to delete information for.
     */
    public static function delete_data_for_user(approved_contextlist $contextlist) {
        global $DB;

        $contextids = array_reduce($contextlist->get_contexts(), function ($carry, $context) {
            if ($context->contextlevel == CONTEXT_MODULE) {
                $carry[] = $context->id;
            }
            return $carry;
        }, []);

        if (empty($contextids)) {
            return;
        }

        $userid = $contextlist->get_user()->id;

        [$insql, $inparams] = $DB->get_in_or_equal($contextids, SQL_PARAMS_NAMED);
        $sql = "SELECT p.id
                  FROM {edwiservideoactivity_progress} p
                  JOIN {context} ctx
                    ON ctx.instanceid = p.cm_id
                   AND ctx.contextlevel = :modlevel
                 WHERE p.user_id = :userid
                   AND ctx.id $insql";
        $params = array_merge($inparams, ['modlevel' => CONTEXT_MODULE, 'userid' => $userid]);

        $progressids = $DB->get_fieldset_sql($sql, $params);
        if (!empty($progressids)) {
            [$insql, $inparams] = $DB->get_in_or_equal($progressids, SQL_PARAMS_NAMED);
            $DB->delete_records_select('edwiservideoactivity_progress', "id $insql", $inparams);
        }
    }

    /**
     * Delete multiple users within a single context.
     *
     * @param approved_userlist $userlist The approved context and user information to delete information for.
     */
    public static function delete_data_for_users(approved_userlist $userlist) {
        global $DB;

        $context = $userlist->get_context();

        if (!is_a($context, \context_module::class)) {
            return;
        }

        $userids = $userlist->get_userids();
        if (empty($userids)) {
            return;
        }

        [$insql, $inparams] = $DB->get_in_or_equal($userids, SQL_PARAMS_NAMED);
        $DB->delete_records_select(
            'edwiservideoactivity_progress',
            "cm_id = :cmid AND user_id $insql",
            array_merge($inparams, ['cmid' => $context->instanceid])
        );
    }
}

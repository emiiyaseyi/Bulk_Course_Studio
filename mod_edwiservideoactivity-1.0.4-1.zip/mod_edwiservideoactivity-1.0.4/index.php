<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * View page for Edwiser Video Activity
 *
 * @package   mod_edwiservideoactivity
 * @copyright 2024 Edwiser
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/completionlib.php');
require_once(__DIR__ . '/lib.php');

$id = required_param('id', PARAM_INT);

$course = $DB->get_record('course', ['id' => $id], '*', MUST_EXIST);
require_login($course);

// Find the first visible edwiservideoactivity cm and redirect to it.
// $id here is the course ID, not the course module ID — passing it directly to
// view.php?id= would break on PostgreSQL/MSSQL where sequences differ from MySQL.
$modinfo = get_fast_modinfo($course);
$cms = $modinfo->get_instances_of('edwiservideoactivity');

if (!empty($cms)) {
    $cm = reset($cms);
    $redirecturl = new moodle_url('/mod/edwiservideoactivity/view.php', ['id' => $cm->id]);
} else {
    $redirecturl = new moodle_url('/course/view.php', ['id' => $id]);
}

redirect($redirecturl);

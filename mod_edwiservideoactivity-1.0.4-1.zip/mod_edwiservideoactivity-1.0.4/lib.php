<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Library of functions and constants for module edwiservideoactivity
 *
 * @package   mod_edwiservideoactivity
 * @copyright 2024 Edwiser
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

use mod_edwiservideoactivity\videoactivity;
use core_course\output\activity_completion;
use core_completion\cm_completion_details;
use core_courseformat\output\local\content\cm\controlmenu;

/**
 * List of features supported in Edwiser Video Activity module
 * @param string $feature FEATURE_xx constant for requested feature
 * @return mixed True if module supports feature, false if not, null if doesn't know
 */
function edwiservideoactivity_supports($feature) {
    switch ($feature) {
        case FEATURE_MOD_ARCHETYPE:
            return MOD_ARCHETYPE_OTHER;
        case FEATURE_MOD_PURPOSE:
            return MOD_PURPOSE_CONTENT;
        case FEATURE_GROUPS:
            return false;
        case FEATURE_GROUPINGS:
            return false;
        case FEATURE_MOD_INTRO:
            return true;
        case FEATURE_COMPLETION_TRACKS_VIEWS:
            return true;
        case FEATURE_COMPLETION_HAS_RULES:
            return true;
        case FEATURE_GRADE_HAS_GRADE:
            return false;
        case FEATURE_GRADE_OUTCOMES:
            return false;
        case FEATURE_BACKUP_MOODLE2:
            return true;
        case FEATURE_SHOW_DESCRIPTION:
            return true;
        default:
            return null;
    }
}

/**
 * Add edwiservideoactivity instance.
 * @param stdClass $edwiservideoactivity
 * @return int new edwiservideoactivity instance id
 */
function edwiservideoactivity_add_instance($data, $mform) {
    global $DB;

    $data->timecreated  = time();
    $data->timemodified = $data->timecreated;

    $data = edwiservideoactivity_set_form_data($data);

    // Insert clean data into DB.
    $data->id = $DB->insert_record('edwiservideoactivity', $data);

    edwiservideoactivity_save_files($data, $mform);

    return $data->id;
}

/**
 * Update edwiservideoactivity instance.
 * @param stdClass $edwiservideoactivity
 * @return bool true
 */
function edwiservideoactivity_update_instance($data, $mform) {
    global $DB, $CFG;

    // Get old record before updating to compare completion percentage and video details.
    $oldrecord = $DB->get_record('edwiservideoactivity', ['id' => $data->instance], '*', MUST_EXIST);
    $oldcompletionpercent = $oldrecord->completionpercent ?? 0;
    $oldsourcetype = $oldrecord->sourcetype ?? 0;
    $oldsourcepath = $oldrecord->sourcepath ?? '';

    $data->timemodified = time();
    $data->id           = $data->instance;

    $data = edwiservideoactivity_set_form_data($data);
    $newcompletionpercent = $data->completionpercent ?? 0;
    $newsourcetype = $data->sourcetype ?? 0;
    $newsourcepath = $data->sourcepath ?? '';

    // Update the record.
    $DB->update_record('edwiservideoactivity', $data);
    // If video source type or path changed, delete all progress records for all users.
    // This ensures users start fresh with the new video.
    if ($oldsourcetype != $newsourcetype || $oldsourcepath != $newsourcepath) {
        // Get course module ID to delete progress records.
        $cmid = $DB->get_field('course_modules', 'id', [
            'instance' => $data->instance,
            'module' => $DB->get_field('modules', 'id', ['name' => 'edwiservideoactivity']),
        ]);

        if ($cmid) {
            // Delete all progress records for this activity using Moodle's standard method.
            $DB->delete_records('edwiservideoactivity_progress', ['cm_id' => $cmid]);
        }
    }

    // If completion percentage changed, reset completion states for all users.
    // This will cause Moodle to re-evaluate completion based on the new threshold.
    if ($oldcompletionpercent != $newcompletionpercent) {
        // Get course.
        $course = $DB->get_record('course', ['id' => $oldrecord->course], '*', MUST_EXIST);

        // Rebuild course cache FIRST to ensure cm object has updated completion percentage.
        // This is critical: the cm object must have the new completion percentage before reset.
        rebuild_course_cache($course->id, true);

        // Get course module with updated data from cache (must get after cache rebuild).
        // Use get_fast_modinfo to get cm_info object with updated customdata.
        $modinfo = get_fast_modinfo($course);
        $cmid = $DB->get_field('course_modules', 'id', [
            'instance' => $data->instance,
            'module' => $DB->get_field('modules', 'id', ['name' => 'edwiservideoactivity']),
        ]);

        if ($cmid) {
            $cm = $modinfo->get_cm($cmid);
            if ($cm) {
                require_once($CFG->libdir . '/completionlib.php');
                $completion = new completion_info($course);

                // Reset all completion states - Moodle will re-evaluate based on new threshold.
                // The cm object now has the updated completion percentage in its customdata.
                $completion->reset_all_state($cm);
            }
        }
    }

    edwiservideoactivity_save_files($data, $mform);

    return true;
}

/**
 * Delete edwiservideoactivity instance.
 * @param int $id
 * @return bool true
 */
function edwiservideoactivity_delete_instance($id) {
    global $DB;

    if (! $edwiservideoactivity = $DB->get_record('edwiservideoactivity', ['id' => $id])) {
        return false;
    }

    // Fetch the course module (cm) from the instance.
    $cm      = get_coursemodule_from_instance('edwiservideoactivity', $edwiservideoactivity->id, $edwiservideoactivity->course);
    $context = context_module::instance($cm->id);

    // Delete all file areas associated with this activity.
    $fs = get_file_storage();
    foreach (['mediafile', 'resources', 'transcript', 'intro'] as $area) {
        $fs->delete_area_files($context->id, 'mod_edwiservideoactivity', $area);
    }

    // Delete DB record.
    $DB->delete_records('edwiservideoactivity', ['id' => $edwiservideoactivity->id]);

    return true;
}

/**
 * Return a small object with summary information about what a
 * user has done with a given particular instance of this module
 * Used for user activity reports.
 * @param stdClass $course
 * @param stdClass $user
 * @param stdClass $mod
 * @param stdClass $edwiservideoactivity
 * @return stdClass|null
 */
function edwiservideoactivity_user_outline($course, $user, $mod, $edwiservideoactivity) {
    global $DB;

    if (
        $logs = $DB->get_records(
            'log',
            ['userid' => $user->id, 'module' => 'edwiservideoactivity', 'action' => 'view', 'info' => $edwiservideoactivity->id],
            'time ASC'
        )
    ) {
        $numviews = count($logs);
        $lastlog = array_pop($logs);

        $result = new stdClass();
        $result->info = get_string('numviews', '', $numviews);
        $result->time = $lastlog->time;

        return $result;
    }
    return null;
}

/**
 * Print a detailed representation of what a user has done with
 * a given particular instance of this module, for user activity reports.
 * @param stdClass $course
 * @param stdClass $user
 * @param stdClass $mod
 * @param stdClass $edwiservideoactivity
 * @return bool
 */
function edwiservideoactivity_user_complete($course, $user, $mod, $edwiservideoactivity) {
    global $DB;

    if (
        $logs = $DB->get_records(
            'log',
            ['userid' => $user->id, 'module' => 'edwiservideoactivity', 'action' => 'view', 'info' => $edwiservideoactivity->id],
            'time ASC'
        )
    ) {
        $numviews = count($logs);
        $lastlog = array_pop($logs);

        $strmostrecently = get_string('mostrecently');
        $strnumviews = get_string('numviews', '', $numviews);

        echo "$strnumviews - $strmostrecently " . userdate($lastlog->time);
    } else {
        echo get_string('neverseen', 'edwiservideoactivity');
    }
}

/**
 * Save files for the edwiservideoactivity instance.
 *
 * @param stdClass $data Form data
 * @param moodleform $mform Form instance
 */
function edwiservideoactivity_save_files($data, $mform) {
    global $DB;

    $context = context_module::instance($data->coursemodule);

    // Handle media source logic.
    if (! empty($data->mediasource) && $data->mediasource === 'upload') {
        // Save media file (if uploaded).
        if (! empty($data->mediafile)) {
            file_save_draft_area_files(
                $data->mediafile,
                $context->id,
                'mod_edwiservideoactivity',
                'mediafile',
                0,
                ['subdirs' => 0]
            );

            // Save file path for uploaded file.
            $fs    = get_file_storage();
            $files = $fs->get_area_files(
                $context->id,
                'mod_edwiservideoactivity',
                'mediafile',
                0,
                'itemid, filepath, filename',
                false
            );
            if ($files) {
                $file      = reset($files);
                $sourceurl = moodle_url::make_pluginfile_url(
                    $context->id,
                    'mod_edwiservideoactivity',
                    'mediafile',
                    0,
                    $file->get_filepath(),
                    $file->get_filename()
                );
                $data->sourcepath = $sourceurl->out(false);

                $DB->set_field('edwiservideoactivity', 'sourcepath', $data->sourcepath, ['id' => $data->id]);
            }
        }
    }

    // Save intro editor files.
    if (! empty($data->introeditor['itemid']) && is_numeric($data->introeditor['itemid'])) {
        file_save_draft_area_files(
            $data->introeditor['itemid'],
            $context->id,
            'mod_edwiservideoactivity',
            'intro',
            0,
            ['subdirs' => 0]
        );
    }

    // Save resources.
    if (! empty($data->resources)) {
        file_save_draft_area_files(
            $data->resources,
            $context->id,
            'mod_edwiservideoactivity',
            'resources',
            0,
            ['subdirs' => 0]
        );
    }

    // Save transcript.
    if (! empty($data->transcript)) {
        file_save_draft_area_files(
            $data->transcript,
            $context->id,
            'mod_edwiservideoactivity',
            'transcript',
            0,
            ['subdirs' => 0]
        );
    }

    // Data availability flags.
    $draftinfo = file_get_draft_area_info($data->resources);
    if ($draftinfo['filecount'] == 0) {
        $DB->set_field('edwiservideoactivity', 'hasresources', 0, ['id' => $data->id]);
    }

    $draftinfo = file_get_draft_area_info($data->transcript);
    if ($draftinfo['filecount'] == 0) {
        $DB->set_field('edwiservideoactivity', 'hastranscript', 0, ['id' => $data->id]);
    }
}

/**
 * Serves the files from the edwiservideoactivity file areas.
 *
 * @param stdClass $course Course object
 * @param stdClass $cm Course module object
 * @param context $context Context object
 * @param string $filearea File area
 * @param array $args Extra arguments
 * @param bool $forcedownload Whether or not force download
 * @param array $options Additional options affecting the file serving
 * @return bool false if file not found
 */
function edwiservideoactivity_pluginfile($course, $cm, $context, $filearea, $args, $forcedownload, array $options = []) {
    global $DB;

    // Ensure the context is at the module level.
    if ($context->contextlevel !== CONTEXT_MODULE) {
        return false;
    }

    // Require course login and check capabilities.
    require_course_login($course, true, $cm);

    if (! has_capability('mod/edwiservideoactivity:view', $context)) {
        return false;
    }

    // Handle intro separately — Moodle will take care of it.
    $validfileareas = ['mediafile', 'resources', 'transcript'];
    if (! in_array($filearea, $validfileareas)) {
        return false;
    }

    // Remove the "revision" parameter to avoid caching issues.
    array_shift($args);

    // Reconstruct the file path.
    $relativepath = implode('/', $args);
    $fullpath     = "/$context->id/mod_edwiservideoactivity/$filearea/0/$relativepath";

    $fs   = get_file_storage();
    $file = $fs->get_file_by_hash(sha1($fullpath));

    if (! $file || $file->is_directory()) {
        return false;
    }

    // Set security headers for inline preview if needed.
    if (! $forcedownload) {
        header("Content-Security-Policy: default-src 'none'; img-src 'self'; media-src 'self'");
    }

    // Serve the file.
    send_stored_file($file, 0, 0, $forcedownload, $options);
}

/**
 * Set form data for the edwiservideoactivity instance.
 *
 * @param stdClass $data Form data
 * @return stdClass Modified form data
 */
function edwiservideoactivity_set_form_data($data) {
    // Set media source.
    if ($data->mediasource === 'upload') {
        $data->sourcetype = 1;
        $data->sourcepath = '';
    } else if ($data->mediasource === 'url') {
        $data->sourcetype = 2;
        $data->sourcepath = $data->mediaurl;
    } else {
        $data->sourcetype = 3;
        $data->sourcepath = $data->embedcode;
    }

    // Set flags.
    $data->hasresources  = ! empty($data->resources) ? 1 : 0;
    $data->hastranscript = ! empty($data->transcript) ? 1 : 0;

    // Set completion percentage (default to 0 if not set or disabled).
    // Handle both suffixed (from default completion form) and non-suffixed (from module settings) field names.
    $completionpercentenabled = null;
    $completionpercent = null;

    // First check for non-suffixed fields (module settings form).
    if (isset($data->completionpercentenabled)) {
        $completionpercentenabled = $data->completionpercentenabled;
        $completionpercent = $data->completionpercent ?? 0;
    } else {
        // Check for suffixed fields (default completion form).
        foreach (get_object_vars($data) as $key => $value) {
            if (str_starts_with($key, 'completionpercentenabled') && strlen($key) > strlen('completionpercentenabled')) {
                $completionpercentenabled = $value;
                $suffix = substr($key, strlen('completionpercentenabled'));
                $completionpercentkey = 'completionpercent' . $suffix;
                if (isset($data->$completionpercentkey)) {
                    $completionpercent = $data->$completionpercentkey;
                    // Remove suffixed fields after processing.
                    unset($data->$key);
                    unset($data->$completionpercentkey);
                }
                break;
            }
        }
    }

    // Set completion percentage (default to 0 if not set or disabled).
    if (empty($completionpercentenabled) || empty($completionpercent)) {
        $data->completionpercent = 0;
    } else {
        $data->completionpercent = (int) $completionpercent;
    }

    return $data;
}

/**
 * Check if a video URL is embedded using pattern matching
 *
 * @param string $url The video URL to check
 * @return bool True if the URL is embedded, false if it's a direct video file
 */
function mod_edwiservideoactivity_is_embedded_video_url($url) {
    if (empty($url)) {
        return false;
    }

    // Check for direct video file extensions.
    $videoextensions = ['mp4', 'avi', 'mov', 'wmv', 'flv', 'webm', 'mkv', 'm4v', '3gp', 'ogv', 'ts'];
    $isdirectvideo = preg_match('/\.(' . implode('|', $videoextensions) . ')(\?|$)/i', $url);

    // If URL has video extension, it's not embedded; otherwise, it's embedded.
    return !$isdirectvideo;
}

/**
 * Get availability information for a course module
 *
 * @param stdClass $course Course object
 * @param cm_info $cm Course module info
 * @param \renderer_base $output Renderer object
 * @return array Availability information array
 */
function mod_edwiservideoactivity_get_availability_info($course, $cm, $output) {
    global $CFG;

    if (empty($CFG->enableavailability)) {
        return ['hasavailability' => false];
    }

    $availabilityinfo = [];
    $hasavailability = false;

    // Check if user can view hidden activities.
    $canviewhidden = has_capability('moodle/course:viewhiddenactivities', $cm->context);

    if (!$cm->uservisible) {
        // User cannot see the module but might be allowed to see availability info.
        if (!empty($cm->availableinfo)) {
            $hasavailability = true;
            $availabilityinfo[] = (object) [
                'text' => \core_availability\info::format_info($cm->availableinfo, $course),
                'isrestricted' => 1,
                'isfullinfo' => 0,
                'classes' => 'isrestricted',
            ];
        }
    } else if ($canviewhidden) {
        // Teacher/editor can see all restrictions.
        $ci = new \core_availability\info_module($cm);
        $fullinfo = $ci->get_full_information();
        if ($fullinfo) {
            $hasavailability = true;
            $classes = 'isrestricted isfullinfo';
            if (!$cm->visible) {
                $classes .= ' hide';
            }
            $availabilityinfo[] = (object) [
                'text' => \core_availability\info::format_info($fullinfo, $course),
                'isrestricted' => 1,
                'isfullinfo' => 1,
                'classes' => $classes,
            ];
        }
    }

    return [
        'hasavailability' => $hasavailability,
        'info' => $availabilityinfo,
    ];
}

/**
 * Get the template context for the edwiservideoactivity view page.
 *
 * @param int $id Course module ID
 * @param string $activitytype Activity type
 * @return array Template context data
 */
function mod_edwiservideoactivity_get_context($id, $activitytype = 'edwiservideoactivity') {
    global $DB, $PAGE, $OUTPUT, $USER, $CFG;

    // Validate the $id parameter.
    if (empty($id) || !is_numeric($id) || $id <= 0) {
        // Return empty context if invalid ID.
        return [];
    }

    if ($activitytype != 'edwiservideoactivity') {
        $cm = get_coursemodule_from_id($activitytype, $id, 0, false, MUST_EXIST);

        // Use the modname to get the instance from the correct table.
        $instance = $DB->get_record($cm->modname, ['id' => $cm->instance], '*', MUST_EXIST);
        $course   = $DB->get_record('course', ['id' => $cm->course], '*', MUST_EXIST);
        $category = $DB->get_record('course_categories', ['id' => $course->category], '*', MUST_EXIST);
        require_login($course, true, $cm);
        $context = context_module::instance($cm->id);

        // Section name and menu.
        $modinfo     = get_fast_modinfo($course);
        $mod = $modinfo->get_cm($cm->id);
        $sectioninfo = $modinfo->get_section_info_by_id($cm->section);
        $sectionname = strtoupper(strip_tags(format_text(get_section_name($course, $sectioninfo))));

        // Next and prev btn.
        $navbtn = mod_edwiservideoactivity_get_next_prevbtn($course, $cm);

        // Get availability information.
        $availabilityinfo = mod_edwiservideoactivity_get_availability_info($course, $mod, $OUTPUT);

        $hasresources = false;
        $hastranscript = false;

        // Determine if user has editing capabilities in this course.
        $coursecontext = context_course::instance($course->id);
        $iseditingteacher = has_capability('moodle/course:manageactivities', $coursecontext);

        $templatecontext = [
            'title'             => strip_tags(format_text($mod->name)),
            'sectionname'       => $sectionname,
            'intro'             => format_text(
                file_rewrite_pluginfile_urls(
                    $instance->intro,
                    'pluginfile.php',
                    $context->id,
                    'mod_' . $activitytype,
                    'intro',
                    null
                ),
                $instance->introformat,
                ['context' => $context]
            ),
            'completionbutton'  => mod_edwiservideoactivity_get_completion_button($course, $cm),
            'completionpercent' => mod_edwiservideoactivity_get_section_completionpercent($course, $cm)['completionpercent'],
            'completed' => mod_edwiservideoactivity_get_course_completion_counts($course)['completed'],
            'total' => mod_edwiservideoactivity_get_course_completion_counts($course)['total'],
            'hasresources'      => $hasresources,
            'hastranscript'     => $hastranscript,
            'hasprogressinfo'   => mod_edwiservideoactivity_get_section_completionpercent($course, $cm)['hasprogressinfo'],
            'activitymenu'       => mod_edwiservideoactivity_get_cm_activity_menu($course, $sectioninfo, $cm),
            'customprevurl'     => $navbtn['prevurl'],
            'customnexturl'     => $navbtn['nexturl'],
            'nextactivityname'  => $navbtn['nextactivityname'],
            'isedwiservideoactivity' => false,
            'quizurl' => $mod->url->out(),
            'coursedata' => [
                'coursename' => strip_tags(format_text($course->fullname)),
                'courseurl'  => $CFG->wwwroot . '/course/view.php?id=' . $course->id,
            ],
            'categorydata' => [
                'coursecategory' => $category->name,
                'categoryurl'  => $CFG->wwwroot . '/course/index.php?categoryid=' . $category->id,
            ],
            'courseprogress' => mod_edwiservideoactivity_get_course_progress_percentage($course),
            'make_transcript_active' => empty($overview['intro']) && !($hasresources),
            'showtabs' => $hasresources || $hastranscript || !empty($instance->intro),
            'iconurl' => $OUTPUT->image_url('icon', 'mod_' . $cm->modname)->out(),
            'isquiz' => ($activitytype == 'quiz'),
            'isedwiservideoformat' => ($course->format === 'edwiservideoformat'),
            'isediting' => $PAGE->user_is_editing(),
            'iseditingteacher' => $iseditingteacher,
        ];

        // Merge availability information.
        $templatecontext = array_merge($templatecontext, $availabilityinfo);
    } else {
        // Get course module, course, and activity record.
        $cm                   = get_coursemodule_from_id('edwiservideoactivity', $id, 0, false, MUST_EXIST);
        $course               = $DB->get_record('course', ['id' => $cm->course], '*', MUST_EXIST);
        $category = $DB->get_record('course_categories', ['id' => $course->category], '*', MUST_EXIST);
        $edwiservideoactivity = $DB->get_record('edwiservideoactivity', ['id' => $cm->instance], '*', MUST_EXIST);

        // User login and capability checks.
        require_login($course, true, $cm);
        $context = context_module::instance($cm->id);

        // Trigger module viewed event.
        $event = \mod_edwiservideoactivity\event\course_module_viewed::create([
            'objectid' => $edwiservideoactivity->id,
            'context'  => $context,
        ]);
        $event->add_record_snapshot('course', $course);
        $event->add_record_snapshot('edwiservideoactivity', $edwiservideoactivity);
        $event->trigger();

        // Setup page.
        $PAGE->set_url('/mod/edwiservideoactivity/view.php', ['id' => $cm->id]);
        $PAGE->set_title(format_string($edwiservideoactivity->name));
        $PAGE->set_heading(format_string($course->fullname));
        $PAGE->set_context($context);
        $PAGE->set_pagelayout('incourse');

        // Instantiate the videoactivity helper class.
        $activity   = new videoactivity($cm->instance);
        $media      = $activity->get_media_data();
        $name       = strip_tags(format_text($activity->get_name()));
        $overview   = $activity->get_overview_data();
        $resources  = $activity->get_resource_context();
        $transcript = $activity->get_transcript_context();

        // Get section name.
        $modinfo     = get_fast_modinfo($course);
        $mod = $modinfo->get_cm($cm->id);
        $sectioninfo = $modinfo->get_section_info_by_id($cm->section);
        $sectionname = strtoupper(strip_tags(format_text(get_section_name($course, $sectioninfo))));

        // Load transcript text from file.
        $transcripttext = '';
        if (isset($transcript['transcript']) && pathinfo($transcript['transcript']['filename'], PATHINFO_EXTENSION) === 'txt') {
            $transcripttext = nl2br(s($transcript['transcript']['content']));
        }

        // Next and prev btn.
        $navbtn = mod_edwiservideoactivity_get_next_prevbtn($course, $cm);

        // Get availability information.
        $availabilityinfo = mod_edwiservideoactivity_get_availability_info($course, $mod, $OUTPUT);

        $hasresources = false;
        $hastranscript = false;
        if ($media['sourcetype'] == 3) {
            preg_match('/src="([^"]+)"/', $media['sourcepath'], $matches);
            if (! empty($matches[1])) {
                $srcurl           = $matches[1];
                $media['sourcepath'] = $srcurl;
            }
        }

        // Determine if user has editing capabilities in this course.
        $coursecontext = context_course::instance($course->id);
        $iseditingteacher = has_capability('moodle/course:manageactivities', $coursecontext);

        // Add Plyr configuration to template context.
        $templatecontext = [
            'title'             => $name,
            'sectionname'       => $sectionname,
            'sourcepath'        => $media['sourcetype'] == 3
                                    && strpos($media['sourcepath'], 'youtube.com') !== false
                                    ? $media['sourcepath']
                                        . (strpos($media['sourcepath'], '?') !== false ? '&' : '?')
                                        . 'enablejsapi=1'
                                    : $media['sourcepath'],
            'isembeded'         => ($media['sourcetype'] == 3
                                    || ($media['sourcetype'] == 2
                                        && isset($media['sourcepath'])
                                        && mod_edwiservideoactivity_is_embedded_video_url($media['sourcepath']))),
            'intro'             => format_text(
                file_rewrite_pluginfile_urls(
                    $overview['intro'],
                    'pluginfile.php',
                    $context->id,
                    'mod_edwiservideoactivity',
                    'intro',
                    null
                ),
                $overview['introformat'],
                ['context' => $context]
            ),
            'resources'         => $resources['resources'],
            'transcripttext'    => $transcripttext,
            'completionbutton'  => mod_edwiservideoactivity_get_completion_button($course, $cm),
            'completionpercent' => mod_edwiservideoactivity_get_section_completionpercent($course, $cm)['completionpercent'],
            'completed' => mod_edwiservideoactivity_get_course_completion_counts($course)['completed'],
            'total' => mod_edwiservideoactivity_get_course_completion_counts($course)['total'],
            'hasresources'      => ($activity->has_resources() == 1),
            'hastranscript'     => ($activity->has_transcript() == 1),
            'hasprogressinfo'   => mod_edwiservideoactivity_get_section_completionpercent($course, $cm)['hasprogressinfo'],
            'activitymenu'       => mod_edwiservideoactivity_get_cm_activity_menu($course, $sectioninfo, $cm),
            'customprevurl'     => $navbtn['prevurl'],
            'customnexturl'     => $navbtn['nexturl'],
            'nextactivityname'  => $navbtn['nextactivityname'],
            'isedwiservideoactivity' => true,
            'coursedata' => [
                'coursename' => strip_tags(format_text($course->fullname)),
                'courseurl'  => $CFG->wwwroot . '/course/view.php?id=' . $course->id,
            ],
            'categorydata' => [
                'coursecategory' => $category->name,
                'categoryurl'  => $CFG->wwwroot . '/course/index.php?categoryid=' . $category->id,
            ],
            'courseprogress'    => mod_edwiservideoactivity_get_course_progress_percentage($course),
            'make_transcript_active' => empty($overview['intro']) && !($activity->has_resources() == 1),
            'showtabs' => ($activity->has_resources() == 1) || ($activity->has_transcript() == 1) || !empty($overview['intro']),
            'isedwiservideoformat' => ($course->format === 'edwiservideoformat'),
            'isediting' => $PAGE->user_is_editing(),
            'iseditingteacher' => $iseditingteacher,
            // Plyr configuration.
            'cmid' => $cm->id,
            'autoplay' => false, // Can be made configurable.
            'showcontrols' => true,
            'controls' => 'play-large,play,progress,current-time,mute,volume,fullscreen',
            'speed' => '0.5,0.75,1,1.25,1.5,2',
        ];

        // Merge availability information.
        $templatecontext = array_merge($templatecontext, $availabilityinfo);

        // Initialize Plyr based on sourcetype.
        if ($media['sourcetype'] == 1) {
            // Upload.
            $PAGE->requires->js_call_amd('mod_edwiservideoactivity/player_init', 'init', ["#video-{$cm->id}"]);
        } else if ($media['sourcetype'] == 2) {
            // URL.
            $PAGE->requires->js_call_amd('mod_edwiservideoactivity/player_init', 'init', ["#video-{$cm->id}"]);
        }

        // Check if user is logged in (not guest and has real user ID).
        // Guest users will use localStorage instead of database for progress tracking.
        $isloggedin = isloggedin() && !isguestuser();
        // Load language strings for JS progress tracker.
        $PAGE->requires->strings_for_js([
            'startsin',
            'second',
            'seconds',
        ], 'mod_edwiservideoactivity');
        // Initialize progress tracking based on sourcetype.
        if ($media['sourcetype'] == 1 || $media['sourcetype'] == 2) {
            // HTML5/Plyr tracking.
            $PAGE->requires->js_call_amd(
                'mod_edwiservideoactivity/progress_tracker',
                'init',
                [
                    $cm->id, $media['sourcetype'], $media['sourcepath'],
                    "video-{$cm->id}", $edwiservideoactivity->completionpercent ?? 0, $isloggedin,
                ]
            );
        } else if ($media['sourcetype'] == 3) {
            // Embed video tracking (YouTube/Vimeo/etc).
            $PAGE->requires->js_call_amd(
                'mod_edwiservideoactivity/progress_tracker',
                'init',
                [
                    $cm->id, $media['sourcetype'], $media['sourcepath'],
                    "iframe-{$cm->id}", $edwiservideoactivity->completionpercent ?? 0, $isloggedin,
                ]
            );
        }
    }
    $PAGE->requires->js_call_amd('mod_edwiservideoactivity/activity_ui', 'init');

    return $templatecontext;
}

/**
 * Get the next and previous navigation button URLs.
 *
 * @param stdClass $course Course object
 * @param stdClass $cm Course module object
 * @return array Navigation button data
 */
function mod_edwiservideoactivity_get_next_prevbtn($course, $cm) {
    global $CFG, $COURSE;
    $modinfo = get_fast_modinfo($course);
    $cms     = $modinfo->cms;
    $cmslist = array_values(array_filter($cms, function ($mod) {
        return $mod->uservisible && $mod->has_view();
    }));
    $index   = array_search($cm->id, array_column($cmslist, 'id'));
    $prevurl = $nexturl = null;
    $nextactivityname = null;
    $format = \core_courseformat\base::instance($COURSE);
    $formatoptions = $format->get_format_options();
    $isedwiservideoformat = $course->format === 'edwiservideoformat';
    $displaymode = $formatoptions['activity_display_mode'] ?? 0;
    if ($index !== false) {
        if (! empty($cmslist[$index - 1])) {
            $prevcm  = $cmslist[$index - 1];
            if ($displaymode === 0 && $isedwiservideoformat) {
                $prevurl = $CFG->wwwroot . '/course/view.php?id=' . $course->id .
                    '&modtype=' . $prevcm->modname .
                    '&modid=' . $prevcm->id;
            } else {
                $prevurl = $CFG->wwwroot . '/mod/' . $prevcm->modname . '/view.php?id=' . $prevcm->id;
            }
        }
        if (! empty($cmslist[$index + 1])) {
            $nextcm  = $cmslist[$index + 1];
            if ($displaymode === 0 && $isedwiservideoformat) {
                $nexturl = $CFG->wwwroot . '/course/view.php?id=' . $course->id .
                    '&modtype=' . $nextcm->modname .
                    '&modid=' . $nextcm->id;
            } else {
                $nexturl = $CFG->wwwroot . '/mod/' . $nextcm->modname . '/view.php?id=' . $nextcm->id;
            }
            $nextactivityname = $nextcm->name;
        }
    }
    return [
        'prevurl' => $prevurl,
        'nexturl' => $nexturl,
        'nextactivityname' => $nextactivityname,
    ];
}

/**
 * Get the completion button HTML for a course module.
 *
 * @param stdClass $course Course object
 * @param stdClass $cm Course module object
 * @return string Completion button HTML
 */
function mod_edwiservideoactivity_get_completion_button($course, $cm) {
    global $USER, $PAGE, $OUTPUT;
    $modinfo              = get_fast_modinfo($course);
    $mod                  = $modinfo->get_cm($cm->id);
    $cmcompletion         = cm_completion_details::get_instance($mod, $USER->id);
    $completion           = new activity_completion($mod, $cmcompletion);
    $renderer             = $PAGE->get_renderer('core_course');
    $completiondata       = $completion->export_for_template($renderer);
    $completionbuttonhtml = $OUTPUT->render_from_template('mod_edwiservideoactivity/core_course/activity_info', $completiondata);
    return $completionbuttonhtml;
}

/**
 * Get the section completion percentage for a course module.
 *
 * @param stdClass $course Course object
 * @param stdClass $cm Course module object
 * @return array Completion percentage data
 */
function mod_edwiservideoactivity_get_section_completionpercent($course, $cm) {
    global $USER;
    $modinfo = get_fast_modinfo($course);
    $mod = $modinfo->get_cm($cm->id);
    $sectionnumber = $mod->sectionnum;
    $completioninfo = new completion_info($course);
    $sectionmods    = $modinfo->get_sections()[$sectionnumber] ?? [];
    $total     = 0;
    $completed = 0;
    foreach ($sectionmods as $modid) {
        $modcm = $modinfo->get_cm($modid);
        if (! $modcm->uservisible || ! $modcm->completion) {
            continue;
        }
        $total++;
        $cdata = $completioninfo->get_data($modcm, false, $USER->id);
        if (! empty($cdata->completionstate)) {
            $completed++;
        }
    }
    $hasprogressinfo   = $total > 0;
    $completionpercent = $total > 0 ? floor(($completed / $total) * 100) : 0;
    if (!$completioninfo->is_tracked_user($USER->id)) {
        $completionpercent = $completed = $total = 0;
    }
    return [
        'hasprogressinfo' => $hasprogressinfo,
        'completionpercent' => $completionpercent,
        'completed' => $completed,
        'total' => $total,
    ];
}

/**
 * Get the course progress percentage.
 *
 * @param stdClass $course Course object
 * @return int Course progress percentage
 */
function mod_edwiservideoactivity_get_course_progress_percentage($course) {
    if (!$course->enablecompletion) {
        return 0;
    }
    $percentage = \core_completion\progress::get_course_progress_percentage($course);
    if (!is_null($percentage)) {
        return floor($percentage);
    }
    return 0;
}

/**
 * Get course-wide completion counts for current user.
 * Counts only visible activities with completion enabled.
 *
 * @param stdClass $course Course object
 * @return array { completed: int, total: int }
 */
function mod_edwiservideoactivity_get_course_completion_counts($course) {
    global $USER;
    $modinfo = get_fast_modinfo($course);
    $completioninfo = new completion_info($course);
    $total = 0;
    $completed = 0;
    foreach ($modinfo->cms as $modcm) {
        if (!$modcm->uservisible || !$modcm->completion) {
            continue;
        }
        $total++;
        $cdata = $completioninfo->get_data($modcm, false, $USER->id);
        if (!empty($cdata->completionstate)) {
            $completed++;
        }
    }
    if (!$completioninfo->is_tracked_user($USER->id)) {
        $completed = 0;
    }
    return [
        'completed' => $completed,
        'total' => $total,
    ];
}

/**
 * Get the activity menu HTML for a course module.
 *
 * @param stdClass $course Course object
 * @param section_info $sectioninfo Section info object
 * @param stdClass $cm Course module object
 * @return string Activity menu HTML
 */
function mod_edwiservideoactivity_get_cm_activity_menu($course, $sectioninfo, $cm) {
    global $PAGE;
    $modinfo = get_fast_modinfo($course);
    $mod = $modinfo->get_cm($cm->id);
    $format = course_get_format($course);
    $renderer = $format->get_renderer($PAGE);
    $controlmenu = new controlmenu($format, $sectioninfo, $mod);
    $menuhtml = $renderer->render($controlmenu);
    return $menuhtml;
}

/**
 * Get completion active rule descriptions
 *
 * @param cm_info $cm Course module info
 * @return array Array of completion rule descriptions
 */
function edwiservideoactivity_get_completion_active_rule_descriptions($cm) {
    if (empty($cm->customdata["customcompletionrules"]) || $cm->completion != COMPLETION_TRACKING_AUTOMATIC) {
        return [];
    }

    $descriptions = [];
    $completionpercent = $cm->customdata["customcompletionrules"]["completionpercent"] ?? 0;
    if ($completionpercent > 0) {
        $descriptions[] = get_string('requirespercent', 'edwiservideoactivity', $completionpercent);
    }
    return $descriptions;
}

/**
 * Get course module info
 *
 * @param stdClass $coursemodule Course module object
 * @return cached_cm_info|null Course module info
 */
function edwiservideoactivity_get_coursemodule_info($coursemodule) {
    global $DB;

    $edwiservideoactivity = $DB->get_record(
        "edwiservideoactivity",
        ["id" => $coursemodule->instance],
        "id, name, intro, introformat, completionpercent"
    );
    if (!$edwiservideoactivity) {
        return null;
    }

    $info = new cached_cm_info();
    $info->name = $edwiservideoactivity->name;

    if ($coursemodule->showdescription) {
        $info->content = format_module_intro("edwiservideoactivity", $edwiservideoactivity, $coursemodule->id, false);
    }

    if ($coursemodule->completion == COMPLETION_TRACKING_AUTOMATIC) {
        $info->customdata["customcompletionrules"]["completionpercent"] = $edwiservideoactivity->completionpercent;
    }

    return $info;
}

/**
 * Obtains the automatic completion state for this activity based on any conditions
 * in activity settings.
 *
 * @param object $course Course
 * @param object $cm Course-module
 * @param int $userid User ID
 * @param bool $type Type of comparison (or/and; can be used as return value if no conditions)
 * @return bool True if completed, false if not, $type if conditions not set.
 */
function edwiservideoactivity_get_completion_state($course, $cm, $userid, $type) {
    global $DB;

    // Get activity details.
    $edwiservideoactivity = $DB->get_record('edwiservideoactivity', ['id' => $cm->instance], '*', MUST_EXIST);

    // If completion percentage is enabled, check progress.
    if ($edwiservideoactivity->completionpercent > 0) {
        // Get user's progress for this activity.
        $progress = $DB->get_record('edwiservideoactivity_progress', [
            'user_id' => $userid,
            'cm_id' => $cm->id,
        ], 'percent');

        if ($progress && $progress->percent >= $edwiservideoactivity->completionpercent) {
            return true;
        } else {
            return false;
        }
    } else {
        // Completion percentage is not enabled so just return $type.
        return $type;
    }
}
/**
 * Get the template context for the edwiservideoactivity view page.
 *
 * @deprecated Use mod_edwiservideoactivity_get_context() instead.
 * @param int $id Course module ID
 * @param string $activitytype Activity type
 * @return array Template context data
 */
function get_edwiservideoactivity_context($id, $activitytype = 'edwiservideoactivity') {
    return mod_edwiservideoactivity_get_context($id, $activitytype);
}

/**
 * Get the next and previous navigation button URLs.
 *
 * @deprecated Use mod_edwiservideoactivity_get_next_prevbtn() instead.
 * @param stdClass $course Course object
 * @param stdClass $cm Course module object
 * @return array Navigation button data
 */
function get_next_prevbtn($course, $cm) {
    return mod_edwiservideoactivity_get_next_prevbtn($course, $cm);
}

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Edwiser Video Activity - Activity UI (touch navigation and video overlay)
 *
 * @module     mod_edwiservideoactivity/activity_ui
 * @copyright  2025 Edwiser
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

export const init = () => {
    const wrapper = document.querySelector('.video-wrapper');

    let touchTimer = null;
    let isButtonsVisible = false;

    // Show buttons function
    let showButtons = () => {
        if (!wrapper || isButtonsVisible) {
            return;
        }

        wrapper.classList.remove('hide-buttons');
        isButtonsVisible = true;

        // Auto-hide after 3 seconds
        touchTimer = setTimeout(() => {
            hideButtons();
        }, 3000);
    };

    // Hide buttons function
    let hideButtons = () => {
        if (!wrapper || !isButtonsVisible) {
            return;
        }

        wrapper.classList.add('hide-buttons');
        isButtonsVisible = false;

        if (touchTimer) {
            clearTimeout(touchTimer);
            touchTimer = null;
        }
    };

    // Touch event handlers for mobile
    const handleTouchStart = () => {
        showButtons();
    };

    const handleTouchEnd = (e) => {
        // Prevent auto-hide when touching buttons
        if (e.target.closest('.edwactivity-prevbtn') || e.target.closest('.edwactivity-nextbtn')) {
            if (touchTimer) {
                clearTimeout(touchTimer);
                touchTimer = setTimeout(() => {
                    hideButtons();
                }, 3000);
            }
        }
    };

    // Add touch event listeners for mobile
    if (wrapper) {
        wrapper.addEventListener('touchstart', handleTouchStart, {passive: true});
        wrapper.addEventListener('touchend', handleTouchEnd, {passive: true});

        // Special handling for iframe - show buttons on iframe load and keep them visible longer
        const iframe = wrapper.querySelector('iframe');
        if (iframe) {
            // Show buttons when iframe loads
            iframe.addEventListener('load', () => {
                setTimeout(() => {
                    showButtons();
                }, 500);
            });

            // For iframe content, show buttons initially and keep them visible longer
            setTimeout(() => {
                showButtons();
                // Extend visibility time for iframe content
                if (touchTimer) {
                    clearTimeout(touchTimer);
                    touchTimer = setTimeout(() => {
                        hideButtons();
                    }, 5000); // 5 seconds for iframe content
                }
            }, 1000);

            // Global touch detection for iframe content
            var handleGlobalTouchStart = () => {
                // Show buttons on any touch anywhere on the screen
                showButtons();
            };

            // Add global touch listener for iframe content
            document.addEventListener('touchstart', handleGlobalTouchStart, {passive: true});

            // Remove global listener when buttons are hidden
            var originalHideButtons = hideButtons;
            hideButtons = () => {
                originalHideButtons();
                document.removeEventListener('touchstart', handleGlobalTouchStart);
            };
        }

        // Initial auto-hide after 3 seconds
        setTimeout(() => {
            wrapper.classList.add('hide-buttons');
            isButtonsVisible = false;
        }, 3000);
    }

    // Existing video overlay functionality
    const video = document.getElementById('video');
    const overlay = document.getElementById('overlay');

    if (overlay) {
        overlay.addEventListener('click', () => {
            if (video) {
                video.play();
                overlay.style.display = 'none';
            } else {
                // For embedded videos (YouTube/Vimeo), dismiss overlay and cancel redirect
                overlay.classList.add('d-none');
                document.dispatchEvent(new CustomEvent('edwiservideoactivity:cancelredirect'));
            }
        });
    }

    if (video) {
        video.addEventListener('pause', () => {
            if (overlay) {
                overlay.style.display = 'flex';
            }
        });

        video.addEventListener('play', () => {
            if (overlay) {
                overlay.style.display = 'none';
            }
        });
    }
};

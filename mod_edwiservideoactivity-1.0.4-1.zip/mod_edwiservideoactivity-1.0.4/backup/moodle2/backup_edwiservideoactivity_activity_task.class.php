<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Backup activity task for the Edwiser Video Activity module.
 *
 * @package    mod_edwiservideoactivity
 * @copyright  2024 Edwiser
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot . '/mod/edwiservideoactivity/backup/moodle2/backup_edwiservideoactivity_stepslib.php');

/**
 * Backup activity task for the Edwiser Video Activity module.
 *
 * @package    mod_edwiservideoactivity
 * @copyright  2024 Edwiser
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class backup_edwiservideoactivity_activity_task extends backup_activity_task {
    /**
     * Define settings for this activity backup.
     */
    protected function define_my_settings() {
        // No particular settings for this activity.
    }

    /**
     * Define steps for this activity backup.
     */
    protected function define_my_steps() {
        $this->add_step(new backup_edwiservideoactivity_activity_structure_step(
            'edwiservideoactivity_structure',
            'edwiservideoactivity.xml'
        ));
    }

    /**
     * Encode content links for backup.
     *
     * @param string $content Content to encode
     * @return string Encoded content
     */
    public static function encode_content_links($content) {
        global $CFG;

        $base = preg_quote($CFG->wwwroot, "/");

        // Link to the list of edwiservideoactivities.
        $search = "/(" . $base . "\/mod\/edwiservideoactivity\/index.php\?id\=)([0-9]+)/";
        $content = preg_replace($search, '$@EDWISERVIDEOACTIVITYINDEX*$2@$', $content);

        // Link to edwiservideoactivity view by moduleid.
        $search = "/(" . $base . "\/mod\/edwiservideoactivity\/view.php\?id\=)([0-9]+)/";
        $content = preg_replace($search, '$@EDWISERVIDEOACTIVITYVIEWBYID*$2@$', $content);

        return $content;
    }
}

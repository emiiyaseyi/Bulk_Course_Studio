Edwiser Video Activity Plugin for Moodle
==============================================

# Table of Contents

- [Description](#description)
- [Features](#features)
- [Plugin Version](#plugin-version)
- [Required version of Moodle](#required-version-of-moodle)
- [Support](#support)
- [Installation](#installation)
- [Uninstallation](#uninstallation)
- [Files Information](#files-information)
- [Roadmap](#roadmap)
- [History](#history)
- [Author](#author)
- [Provided by](#provided-by)

# Description

Edwiser Video Activity - A Moodle activity module that lets teachers add video content to courses with built-in progress tracking, custom completion conditions, and support for multiple video sources.

Edwiser Video Activity is a Moodle activity plugin designed to seamlessly integrate video content into your courses. Teachers can upload video files directly, paste direct URLs to video files, or embed videos from popular platforms like YouTube and Vimeo using iframe embed codes.

The plugin automatically tracks each student's playback position and percentage watched, allowing learners to resume videos from where they left off. With custom completion conditions, teachers can require students to watch a configurable percentage of the video before the activity is marked as complete. The plugin also supports auto-advancing to the next course activity when the current video finishes.

Each video activity can include an overview description, supplementary resource files, and a transcript — all organized in a clean tabbed interface. HTML5 videos are rendered using the modern Plyr player for an accessible and responsive playback experience.

[(Back to top)](#table-of-contents)

# Features

## Multiple Video Sources
* **Upload File**: Upload .mp4, .mov, or other supported video files directly into Moodle
* **Media URL**: Paste a direct link to a video file (e.g. `https://example.com/video.mp4`)
* **Embed Video**: Paste an `<iframe>` embed code from YouTube, Vimeo, or similar platforms

## Video Progress Tracking
* **Automatic Tracking**: Tracks each student's playback position and percentage watched automatically
* **Resume Playback**: Students can resume videos from where they left off
* **Per-User Progress**: One progress record per user per activity for accurate tracking
* **Provider Tracking**: Tracks video provider (HTML5, YouTube, Vimeo, Loom, etc.) for analytics

## Custom Completion Conditions
* **Percentage-Based Completion**: Set a watch percentage threshold (1–100%) as an activity completion condition
* **Flexible Configuration**: Teachers can configure the required watch percentage per activity
* **Moodle Integration**: Fully integrated with Moodle's activity completion system

## Auto-Advance
* **Automatic Redirect**: Automatically redirects users to the next activity when the current video ends
* **Seamless Navigation**: Provides a seamless learning flow through course activities

## Content Tabs
* **Overview Tab**: Add a description or summary of the video to help learners understand what it covers
* **Resources Tab**: Attach supporting materials or resource files along with the video
* **Transcript Tab**: Add the full transcript of the video for accessibility and reference

## Plyr Video Player
* **Modern Player**: HTML5 videos are rendered with the Plyr player (v3.8.3) for a modern playback experience
* **Accessible**: Accessible video controls and keyboard navigation support
* **Responsive**: Fully responsive player that adapts to all screen sizes

## Backup & Restore
* **Full Support**: Complete support for Moodle's backup and restore system
* **Activity Backup**: Backup and restore video activity settings and configurations

## Web Services
The plugin exposes three AJAX web service functions (login required):

| Function | Description |
|---|---|
| `mod_edwiservideoactivity_save_progress` | Save the current user's video playback position and percentage |
| `mod_edwiservideoactivity_get_progress` | Retrieve the current user's saved progress for a video |
| `mod_edwiservideoactivity_mark_complete` | Mark the video activity as complete for the current user |

[(Back to top)](#table-of-contents)

# Plugin Version

v1.0.1 - Current Release

[(Back to top)](#table-of-contents)

# Required version of Moodle

This version works with Moodle 4.5 and above until the next release.

Please ensure that your hardware and software complies with 'Requirements' in 'Installing Moodle' on
'https://docs.moodle.org/39/en/Step-by-step_Installation_Guide_for_Ubuntu'.

## Minimum Requirements
* PHP version 7.4 or greater (PHP 8.0+ recommended)
* Moodle 4.5 or higher

[(Back to top)](#table-of-contents)

# Support

For all support queries related to Edwiser Video Activity plugin you could email us at support@wisdmlabs.com

Apart from that you could raise your support queries in this forum too - https://forums.edwiser.org/

And if you wish to see any new features as part of the product then you could share your feature requests here
forum https://forums.edwiser.org/ for support.
Together we could make this solution better for your Moodle.

[(Back to top)](#table-of-contents)

# Installation

## Moodle Plugin Automatic Installation
* Download the Edwiser Video Activity plugin package.
* Go to Site administration > Plugins > Install plugins in Moodle.
* Upload the plugin zip file.
* Click on "Install plugin from the Zip file".
* Once installed, navigate to Site administration > Notifications to complete the database setup.
* The **Edwiser Video** activity will now be available when adding activities to a course.

## Moodle Plugin Manual Installation
* Download the Edwiser Video Activity plugin package.
* Extract the zip file.
* Upload the `edwiservideoactivity` folder to the `mod` directory of your Moodle installation using FTP or file manager.
* Log in as a site administrator and navigate to Site administration > Notifications.
* Moodle will detect the new plugin and run the database installation automatically.
* The **Edwiser Video** activity will now be available when adding activities to a course.

## Post-Installation Usage
* In a course, turn editing on and click **Add an activity or resource**.
* Select **Edwiser Video** from the activity chooser.
* Choose a video source — Upload file, Media URL, or Embed video.
* Optionally add an overview description, attach resource files, and upload a transcript.
* Under **Activity completion**, enable the custom completion condition and set the required watch percentage.
* Save. Students can now view the video, and their progress will be tracked automatically.

## Building Styles (Optional — Development Only)

The plugin ships with a pre-built `styles.css`. If you need to recompile from SCSS:

```bash
cd mod/edwiservideoactivity
npm install
npx grunt          # compiles scss/styles.scss -> styles.css
```

## Building AMD Modules (Optional — Development Only)

JavaScript source files live in `amd/src/`. To rebuild the minified bundles in `amd/build/`, run the Moodle core Grunt task from your Moodle root:

```bash
npx grunt amd --root=mod/edwiservideoactivity
```

[(Back to top)](#table-of-contents)

# Uninstallation

1. Go to Site administration > Plugins > Plugin overview.
2. Navigate to the Activity modules section and find "Edwiser Video Activity".
3. Click on the "Uninstall" link for the Edwiser Video Activity plugin.
4. Follow the uninstallation prompts.
5. The plugin folder can be removed from the `mod` directory if desired.

**Note**: Uninstalling the plugin will remove all plugin-specific data including video progress records and activity settings. Make sure to backup your site before uninstallation if you want to preserve data.

[(Back to top)](#table-of-contents)

# Files Information

## Languages
---------
The `mod/edwiservideoactivity/lang/` folder contains language files for the plugin.

Currently available language:
* English (en)

Language strings follow Moodle's standard language file format and can be customized as needed.

## Styles
------
The plugin uses SCSS (Sass) for styling. The SCSS files are located in:
* `mod/edwiservideoactivity/scss/styles.scss` — Main plugin styles
* `mod/edwiservideoactivity/scss/plyr.scss` — Plyr video player styles

Compiled CSS file:
* `mod/edwiservideoactivity/styles.css` — Compiled CSS loaded by Moodle

## JavaScript
------
The plugin uses AMD (Asynchronous Module Definition) for JavaScript:
* `mod/edwiservideoactivity/amd/src/player_init.js` — Video player initialization
* `mod/edwiservideoactivity/amd/src/progress_tracker.js` — Video progress tracking logic
* `mod/edwiservideoactivity/amd/src/settings.js` — Activity settings page scripts
* `mod/edwiservideoactivity/amd/src/plyr.js` — Plyr video player library (third-party)
* `mod/edwiservideoactivity/amd/build/` — Compiled/minified JavaScript files

## Templates
------
Mustache templates are located in:
* `mod/edwiservideoactivity/templates/videoactivity.mustache` — Main video activity view
* `mod/edwiservideoactivity/templates/activity.mustache` — Activity layout
* `mod/edwiservideoactivity/templates/activityinfo.mustache` — Activity information display
* `mod/edwiservideoactivity/templates/activityinfo_tabs.mustache` — Tabbed content (overview, resources, transcript)
* `mod/edwiservideoactivity/templates/otheractivity.mustache` — Other activity display
* `mod/edwiservideoactivity/templates/core_course/` — Core course template overrides for completion display

## Third-Party Libraries
------
Third-party libraries are documented in:
* `mod/edwiservideoactivity/thirdpartylibs.xml` — XML file listing all third-party libraries used

Libraries included:
* Plyr 3.8.3 (MIT License) — Modern HTML5 video player

## Database
------
The plugin creates two database tables:
* `edwiservideoactivity` — Stores activity instance settings (name, intro, source type, source path, completion percentage)
* `edwiservideoactivity_progress` — Stores per-user video progress (playback position, percentage watched, provider)

## Key PHP Files
------
* `mod/edwiservideoactivity/lib.php` — Core library functions (add, update, delete instance, etc.)
* `mod/edwiservideoactivity/mod_form.php` — Activity settings form
* `mod/edwiservideoactivity/view.php` — Activity view page
* `mod/edwiservideoactivity/version.php` — Plugin version and requirements
* `mod/edwiservideoactivity/classes/videoactivity.php` — Main video activity class
* `mod/edwiservideoactivity/classes/completion/custom_completion.php` — Custom completion logic
* `mod/edwiservideoactivity/classes/external/` — Web service API classes (save_progress, get_progress, mark_complete)
* `mod/edwiservideoactivity/classes/event/course_module_viewed.php` — Event class for module viewed
* `mod/edwiservideoactivity/backup/moodle2/` — Backup and restore step/task classes

[(Back to top)](#table-of-contents)

# Roadmap

Future enhancements and features planned for Edwiser Video Activity:

1. Support for additional video platforms and providers
2. Video analytics dashboard for teachers
3. Chapter markers and bookmarks within videos
4. Quiz integration within video playback
5. Multi-language subtitle/caption support
6. Bulk video upload and management

For the latest roadmap information, please visit [Edwiser Forums](https://forums.edwiser.org/)

[(Back to top)](#table-of-contents)

# History

See `changes.txt` file in the plugin directory for detailed version history.

## Recent Versions

### Version 1.0.1
* Feature - Added compatibility with Moodle 5.1
* Feature - Custom completion condition added that triggers based on the percentage of the video watched by the student
* Feature - Automatically redirects users to the next activity when the current video ends
* Feature - Added video progress tracking for embedded videos (YouTube, Vimeo) and HTML5 videos, allowing users to resume playback from where they left off
* Tweak - Integrated a new video player library (Plyr) for HTML5 videos
* Tweak - Video source can only change if the completion conditions have not been set or locked
* Fix - Resolved minor UI issues
* Fix - Fixed images not appearing in the description/overview section
* Fix - Fixed the issue where the iframe code was not fully visible after saving it in the video activity source

### Version 1.0.0
* Initial version of Edwiser Video Activity plugin

For complete version history, refer to the `changes.txt` file.

[(Back to top)](#table-of-contents)

# Author

**WisdmLabs**

WisdmLabs is a leading provider of Moodle solutions and WordPress integrations. We specialize in creating powerful, user-friendly plugins and themes that enhance the learning experience.

**Website**: https://wisdmlabs.com/
**Email**: support@wisdmlabs.com

[(Back to top)](#table-of-contents)

# Provided by

[![Edwiser](https://edwiser.org/wp-content/uploads/2025/11/edwiser-logo.webp)](https://edwiser.org)

**Edwiser** - Empowering Online Learning

Edwiser provides comprehensive Moodle solutions including themes, plugins, and integrations to help you create the perfect online learning platform.

**Website**: https://edwiser.org
**Support**: https://forums.edwiser.org/

[(Back to top)](#table-of-contents)

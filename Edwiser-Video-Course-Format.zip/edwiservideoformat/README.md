# Edwiser Video Course Format

## Table of Contents

- [Description](#description)
- [Features](#features)
- [Privacy & External API Disclosure](#privacy--external-api-disclosure)
- [Plugin Version](#plugin-version)
- [Required Version of Moodle](#required-version-of-moodle)
- [Support](#support)
- [Installation](#installation)
- [Uninstallation](#uninstallation)
- [Files Information](#files-information)
- [Roadmap](#roadmap)
- [History](#history)
- [Author](#author)
- [Provided by](#provided-by)

## Description

Edwiser Video Course Format (`format_edwiservideoformat`) is a Moodle course format plugin that transforms standard Moodle courses into video-centric learning experiences. It provides a single-page course layout designed for video-based instruction, where activities can be viewed inline via an embedded iframe or through standard Moodle activity pages.

The format includes a customizable course header with background images, progress tracking, teacher information display, and resume functionality, bringing a modern online-learning-platform feel to Moodle courses.

## Features

- **Video-first course layout** - Single-page course display optimized for video-based learning.
- **Two activity display modes:**
  - **Iframe mode** (default) - Activities load within the course page in an embedded iframe.
  - **Redirect mode** - Activities open on their standard Moodle activity pages.
- **Customizable course header** - Configure background images, background position, background size, and overlay opacity.
- **Progress tracking** - Section-level and overall course progress percentages based on activity completion.
- **Resume / Start functionality** - Automatically resume from the last viewed activity or start a new course.
- **Teacher display** - Shows teacher avatars (up to 4) in the course header.
- **Activity navigation** - Previous/Next buttons for sequential activity navigation.
- **Show more/less** - Expandable course description for long summaries.
- **Mobile-responsive design** - Adapts to different screen sizes and devices.

## Privacy & External API Disclosure

### Personal Data

This plugin does not store any personal user data.

It implements Moodle's Privacy API via `metadata_provider` and declares external data transmission to `edwiser.org` via `add_external_location_link()`, covering the license key, site URL, and licensed user information sent during license operations.

### External API Connections

This plugin connects to the following external services:

1. **Edwiser.org License API**
   - **Endpoint:** `https://edwiser.org/check-update`
   - **Purpose:** License activation, deactivation, and validation.
   - **Data transmitted:** License key, site URL (`$CFG->wwwroot`), plugin name, plugin version, and user agent.
   - **When:** During license activation/deactivation and periodic license status checks.

2. **Edwiser.org User Management API**
   - **Endpoint:** `https://edwiser.org/wp-json/wdm-eddc/v1/potential-users/`
   - **Purpose:** Syncing and retrieving licensed users associated with the license key.
   - **Data transmitted:** License key, site URL, and licensed user email addresses.
   - **When:** During license user management operations.

### Subscription & Paid Service Disclosure

This plugin requires a **paid license key** from [Edwiser.org](https://edwiser.org/) to activate and use the full functionality. The license key is validated against the Edwiser.org License API (see [External API Connections](#external-api-connections) above).

- **License purchase:** [https://edwiser.org/](https://edwiser.org/)
- **License management:** Site Administration > Plugins > Course formats > Edwiser Video Course Format > Edwiser Video Course Format License Setting

**Demo Credentials for Moodle Review Team:**

Please contact **support@wisdmlabs.com** to request demo/test license credentials for plugin review purposes.

## Plugin Version

| Field     | Value              |
|-----------|--------------------|
| Version   | 2025122300         |
| Release   | 1.0.3              |
| Maturity  | Stable             |
| Component | format_edwiservideoformat |

## Required Version of Moodle

- **Minimum Moodle version:** 4.5 
- **Supported Moodle versions:** 4.5 through 5.0+

### Dependencies

| Plugin                   | Minimum Version | Required |
|--------------------------|-----------------|----------|
| mod_edwiservideoactivity | 2025110500      | Yes      |

## Support

For all support queries related to Edwiser Video Course Format you could email us at support@wisdmlabs.com

- **Email:** support@wisdmlabs.com
- **Website:** [https://edwiser.org/](https://edwiser.org/)

## Installation

1. Download the `edwiservideoformat` plugin.
2. Ensure the required dependency `mod_edwiservideoactivity` is already installed.
3. Extract and copy the `edwiservideoformat` folder into your Moodle installation at:
   ```
   <moodle_root>/course/format/
   ```
4. Log in as a site administrator and navigate to **Site Administration** to complete the installation.
5. Activate your license key under **Site Administration > Plugins > Course formats > Edwiser Video Course Format > Edwiser Video Course Format License Setting**.
6. The format will be available when creating or editing a course under **Course Settings > Course format**.

## Uninstallation

1. Navigate to **Site Administration > Plugins > Course formats > Manage course formats**.
2. Disable the **Edwiser Video Course Format** plugin.
3. Ensure no courses are currently using this format. If any are, change their format to another format (e.g., Topics) before proceeding.
4. Navigate to **Site Administration > Plugins > Plugins overview**.
5. Find `format_edwiservideoformat` and click **Uninstall**.
6. Confirm the uninstallation and follow the on-screen prompts.
7. Optionally, delete the `edwiservideoformat` folder from `<moodle_root>/course/format/`.

## Files Information

### Languages

The `course/format/edwiservideoformat/lang/` folder contains language files for the plugin.

Language files are available in:

- English (en)

Language strings follow Moodle's standard language file format and can be customized as needed.

### Styles

The plugin uses SCSS (Sass) for styling. The main SCSS files are located in:

- `course/format/edwiservideoformat/scss/` - Main SCSS files including styles, mixins, variables, and utilities

Compiled CSS files are generated in:

- `course/format/edwiservideoformat/styles.css` - Compiled CSS file

### JavaScript

The plugin uses AMD (Asynchronous Module Definition) for JavaScript:

- `course/format/edwiservideoformat/amd/src/` - Source JavaScript files
- `course/format/edwiservideoformat/amd/build/` - Compiled JavaScript files

### Templates

Mustache templates are located in:

- `course/format/edwiservideoformat/templates/` - All plugin templates

## Roadmap

- Enhanced video playback controls and analytics.
- Additional course header layout options.
- Extended activity completion tracking and reporting.

## History

See `changes.txt` file in the theme directory for detailed version history.

## Recent Versions

### Version 1.0.3
* Tweak - Added license handling when the maximum activation limit is reached.

### Version 1.0.2
* Feature - Added compatibility with Moodle 5.1.
* Feature - Introduced a setting to choose whether to open an activity in an iframe or the Moodle view.
* Feature - Video Course Format now supports all activities provided by Moodle.

### Version 1.0.1
* Tweak - Minor improvements and bug fixes

## Author

WisdmLabs

WisdmLabs is a leading provider of Moodle solutions and WordPress integrations. We specialize in creating powerful, user-friendly plugins and themes that enhance the learning experience.

- Website: https://wisdmlabs.com/ 
- Email: support@wisdmlabs.com

## Provided by

[![Edwiser](https://edwiser.org/wp-content/uploads/2025/11/edwiser-logo.webp)](https://edwiser.org)

**Edwiser** - Empowering Online Learning

Edwiser provides comprehensive Moodle solutions including themes, plugins, and integrations to help you create the perfect online learning platform.

- **Website**: https://edwiser.org
- **Documentation**: https://remui-docs.edwiser.org/
- **My Account**: https://edwiser.org/my-account/

[(Back to top)](#table-of-contents)

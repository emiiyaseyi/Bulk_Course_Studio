<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Edwiser video format license controller is necessary to activate, deactivate or renew license.
 *
 * @package   format_edwiservideoformat
 * @copyright Copyright (c) 2024 WisdmLabs. (http://www.wisdmlabs.com)
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace format_edwiservideoformat;
/**
 * Edwiser video format license controller class
 */
class edwiservideoformat_license_controller {
    /**
     *
     * @var string Short Name for plugin.
     */
    private $pluginshortname = '';

    /**
     *
     * @var string Slug to be used in url and functions name
     */
    private $pluginslug = '';

    /**
     *
     * @var string stores the current plugin version
     */
    private $pluginversion = '';

    /**
     *
     * @var string Handles the plugin name
     */
    private $pluginname = '';

    /**
     *
     * @var string  Stores the URL of store. Retrieves updates from
     *              this store
     */
    private $storeurl = '';

    /**
     *
     * @var string  Name of the Author
     */
    private $authorname = '';

    /**
     * Response data
     * @var array
     */
    public static $responsedata;

    /**
     * Developer Note: This variable is used everywhere to check license information and verify the data.
     * Change the Name of this variable in this file wherever it appears and also remove this comment
     * After you are done with adding Licensing
     * @var array
     */
    public $wdmedwiservideoformatdata = [
        // Plugins short name appears on the License Menu Page.
        'plugin_short_name' => 'edwiser video course format',
        // Data in db. License is checked using two options viz edd_<slug>_license_key and edd_<slug>_license_status.
        'plugin_slug' => 'edwiser-video-course-format', // This slug is used to store the
        // This should be similar to Version tag mentioned in Plugin headers.
        'plugin_version' => '1.0.0', // Current Version of the plugin.
        // Under this Name product should be created on WisdmLabs Site.
        'plugin_name' => 'edwiser video course format',
        // Url where program pings to check if update is available and license validity.
        'store_url' => 'https://edwiser.org/check-update',
        // Author Name.
        'author_name' => 'WisdmLabs',
    ];

    /**
     * Constructor
     */
    public function __construct() {
        $this->authorname       = $this->wdmedwiservideoformatdata['author_name'];
        $this->pluginname       = $this->wdmedwiservideoformatdata['plugin_name'];
        $this->pluginshortname = $this->wdmedwiservideoformatdata['plugin_short_name'];
        $this->pluginslug       = $this->wdmedwiservideoformatdata['plugin_slug'];
        $this->pluginversion    = $this->wdmedwiservideoformatdata['plugin_version'];
        $this->storeurl         = $this->wdmedwiservideoformatdata['store_url'];
    }

    /**
     * The function parses the response come from the edwiser.org
     * on activation and determines is status of the license key.
     *
     *
     * @param  object $licensedata the response retune by the activation request.
     * @return String               returns the license key status
     */
    public function status_update($licensedata) {
        $status = "";
        if ((empty($licensedata->success)) && isset($licensedata->error) && ($licensedata->error == "expired")) {
            $status = 'expired';
        } else if ($licensedata->license == 'invalid' && isset($licensedata->error) && $licensedata->error == "disabled") {
            $status = 'disabled';
        } else if (
            $licensedata->license == 'invalid' && isset($licensedata->error)
            && $licensedata->error == "no_activations_left"
        ) {
            $status = 'no_activations_left';
        } else if ($licensedata->license == 'failed') {
            $status = 'failed';
             $GLOBALS['wdm_license_activation_failed'] = true;
        } else {
            $status = $licensedata->license;
        }

        // Update license status.
        set_config('edd_' . $this->pluginslug . '_license_status', $status, 'format_edwiservideoformat');

        return $status;
    }

    /**
     * Check if there is no license data in response
     * @param  object $licensedata         License data
     * @param  int    $currentresponsecode Current response code from Edwiser site
     * @param  int    $validresponsecode   Valid response code
     * @return bool                        True if license is valid
     */
    public function check_if_no_data($licensedata, $currentresponsecode, $validresponsecode) {
        if (
            $licensedata == null ||
            !in_array((string)$currentresponsecode, $validresponsecode)
        ) {
            // @codingStandardsIgnoreLine
            $GLOBALS[ 'wdm_server_null_response' ] = true;

            // Update license trans.
            set_config(
                'wdm_' . $this->pluginslug . '_license_trans',
                json_encode(['server_did_not_respond', time() + (60 * 60 * 24)]),
                'format_edwiservideoformat'
            );
            return false;
        }
        return true;
    }

    /**
     * Activate theme license
     */
    public function activate_license() {
        global $CFG;
        $licensekey = trim(optional_param('edd_' . $this->pluginslug . '_license_key', '', PARAM_TEXT));

        if ($licensekey) {
            // Check previous license key.
            $prevlicensekey = get_config('format_edwiservideoformat', 'edd_' . $this->pluginslug . '_license_key');
            if ($prevlicensekey !== false && $prevlicensekey !== $licensekey) {
                // Delete previous license users.
                unset_config('evf_edwiser-video-course-format_licensed_users', 'format_edwiservideoformat');
            }

            // Set new license key.
            set_config('edd_' . $this->pluginslug . '_license_key', $licensekey, 'format_edwiservideoformat');

            // Make API call to validate license.
            $curl = new \curl();
            $curl->setopt([
                'CURLOPT_USERAGENT' => 'MoodleSite/' . $CFG->release . ' - ' . $CFG->wwwroot,
                'CURLOPT_TIMEOUT' => 30,
                'CURLOPT_SSL_VERIFYPEER' => false,
            ]);
            $params = [
                'edd_action' => 'activate_license',
                'license' => $licensekey,
                'item_name' => urlencode($this->pluginname),
                'current_version' => $this->pluginversion,
                'url' => urlencode($CFG->wwwroot),
            ];

            // Process response and update status.
            $resp = $curl->post($this->storeurl, $params);
            $currentresponsecode = (string) $curl->info['http_code'];

            $licensedata = json_decode($resp);
            $validresponsecode = ['200', '301'];

            $isdataavailable = $this->check_if_no_data($licensedata, $currentresponsecode, $validresponsecode);

            if ($isdataavailable == false) {
                return;
            }

            $exptime = 0;
            if (isset($licensedata->expires)) {
                $exptime = strtotime($licensedata->expires);
            }
            $curtime = time();

            if (
                isset($licensedata->expires) &&
                ($licensedata->expires !== false) &&
                ($licensedata->expires != 'lifetime') &&
                $exptime <= $curtime &&
                $exptime != 0
            ) {
                $licensedata->error = "expired";
            }

            if (isset($licensedata->renew_link) && ( ! empty($licensedata->renew_link) || $licensedata->renew_link != "")) {
                // Set renew link.
                set_config('wdm_' . $this->pluginslug . '_product_site', $licensedata->renew_link, 'format_edwiservideoformat');
            }

            $licensestatus = $this->status_update($licensedata);
            $this->set_transient_on_activation($licensestatus);
        }
    }

    /**
     * Set transient on activation
     * @param string $licensestatus License status
     */
    public function set_transient_on_activation($licensestatus) {
        $transexpired = false;
        $configname = 'wdm_' . $this->pluginslug . '_license_trans';

        // Check license trans.
        $transvar = get_config('format_edwiservideoformat', $configname);

        if ($transvar) {
            $transvar = json_decode($transvar, true);

            if (is_array($transvar) && time() > $transvar[1] && $transvar[1] > 0) {
                $transexpired = true;
                unset_config($configname, 'format_edwiservideoformat');
            }
        } else {
            $transexpired = true;
        }

        if ($transexpired == false) {
            if (! empty($licensestatus)) {
                if ($licensestatus == 'valid') {
                    $time = time() + 60 * 60 * 24 * 7;
                } else {
                    $time = time() + 60 * 60 * 24;
                }

                // Update license trans.
                set_config($configname, json_encode([$licensestatus, $time]), 'format_edwiservideoformat');
            }
        }
    }

    /**
     * Deactivate theme license
     */
    public function deactivate_license() {
        global $CFG;

        $wpeplicensekey = get_config('format_edwiservideoformat', 'edd_' . $this->pluginslug . '_license_key');

        if (!empty($wpeplicensekey)) {
            // Make API call to deactivate license.
            $curl = new \curl();
            $curl->setopt([
                'CURLOPT_USERAGENT' => 'MoodleSite/' . $CFG->release . ' - ' . $CFG->wwwroot,
                'CURLOPT_TIMEOUT' => 30,
                'CURLOPT_SSL_VERIFYPEER' => false,
            ]);
            $params = [
                'edd_action' => 'deactivate_license',
                'license' => $wpeplicensekey,
                'item_name' => urlencode($this->pluginname),
                'current_version' => $this->pluginversion,
                'url' => urlencode($CFG->wwwroot),
            ];

            // Process response and update status.
            $resp = $curl->post($this->storeurl, $params);
            $currentresponsecode = (string) $curl->info['http_code'];

            $licensedata = json_decode($resp);
            $validresponsecode = ['200', '301'];

            $isdataavailable = $this->check_if_no_data($licensedata, $currentresponsecode, $validresponsecode);

            if ($isdataavailable) {
                if ($licensedata->license == 'deactivated' || $licensedata->license == 'failed') {
                    // Update license status.
                    set_config('edd_' . $this->pluginslug . '_license_status', 'deactivated', 'format_edwiservideoformat');

                    // Update transient data.
                    set_config(
                        'wdm_' . $this->pluginslug . '_license_trans',
                        json_encode(['deactivated', 0]),
                        'format_edwiservideoformat'
                    );
                }
            }
        }
    }

    /**
     * Validate and add data to database
     */
    public function add_data() {
        $systemcontext = \context_system::instance();
        if (!has_capability('format/edwiservideoformat:can_manage_license', $systemcontext)) {
            return;
        }

        // Check if submission came from license page.
        $onlicensepage = optional_param('onEdwiserVideoFormatLicensePage', 0, PARAM_INT);
        if (!$onlicensepage) {
            return;
        }

        // Verify sesskey for CSRF protection.
        require_sesskey();

        // Get license key from form.
        $lk = optional_param('edd_' . $this->pluginslug . '_license_key', '', PARAM_TEXT);
        $lk = trim($lk);
        if ($lk === '') {
            $lk = 'empty';
        }

        // Handle license activation.
        $activateparam = optional_param('edd_' . $this->pluginslug . '_license_activate', '', PARAM_TEXT);
        $deactivateparam = optional_param('edd_' . $this->pluginslug . '_license_deactivate', '', PARAM_TEXT);

        if ($activateparam !== '') {
            set_config('licensekey', $lk, 'format_edwiservideoformat');
            set_config('licensekeyactivate', $activateparam, 'format_edwiservideoformat');
            return $this->activate_license();
        } else if ($deactivateparam !== '') {
            // Handle license deactivation.
            set_config('licensekey', $lk, 'format_edwiservideoformat');
            set_config('licensekeydeactivate', $deactivateparam, 'format_edwiservideoformat');
            return $this->deactivate_license();
        }
    }

    /**
     * Get data from database
     * @return string License status
     */
    public function get_data_from_db() {
        global $CFG;

        if (null !== self::$responsedata) {
            return self::$responsedata;
        }

        $transexpired = false;
        $transconfigname = 'wdm_' . $this->pluginslug . '_license_trans';

        $gettrans = get_config('format_edwiservideoformat', $transconfigname);
        if ($gettrans) {
            $gettrans = json_decode($gettrans, true);
            if (is_array($gettrans) && time() > $gettrans[1] && $gettrans[1] > 0) {
                $transexpired = true;
                $lusers = self::edd_get_users_from_api();
                if (!empty($lusers) && isset($lusers->users)) {
                    $configname = 'evf_edwiser-video-course-format_licensed_users';
                    set_config($configname, json_encode($lusers->users), 'format_edwiservideoformat');
                }
                unset_config($transconfigname, 'format_edwiservideoformat');
            }
        } else {
            $transexpired = true;
        }

        if ($transexpired == true) {
            $licensekey = get_config('format_edwiservideoformat', 'edd_' . $this->pluginslug . '_license_key');

            if ($licensekey) {
                // Make API call to check license.
                $curl = new \curl();
                $curl->setopt([
                    'CURLOPT_USERAGENT' => 'MoodleSite/' . $CFG->release . ' - ' . $CFG->wwwroot,
                    'CURLOPT_TIMEOUT' => 30,
                    'CURLOPT_SSL_VERIFYPEER' => false,
                ]);
                $params = [
                    'edd_action' => 'check_license',
                    'license' => $licensekey,
                    'item_name' => urlencode($this->pluginname),
                    'current_version' => $this->pluginversion,
                    'url' => urlencode($CFG->wwwroot),
                ];
                // Send the request & save response to $resp.
                $resp = $curl->post($this->storeurl, $params);
                $currentresponsecode = (string) $curl->info['http_code'];

                $licensedata = json_decode($resp);

                $validresponsecode = [ '200', '301' ];

                if ($licensedata == null || ! in_array($currentresponsecode, $validresponsecode)) {
                    // If server does not respond, read current license information.
                    $licensestatus = get_config('format_edwiservideoformat', 'edd_' . $this->pluginslug . '_license_status');

                    if (empty($licensedata)) {
                        // Set license transient.
                        set_config(
                            $transconfigname,
                            json_encode(['server_did_not_respond', time() + (60 * 60 * 24)]),
                            'format_edwiservideoformat'
                        );
                    }
                } else {
                    $licensestatus = $licensedata->license;
                }

                if (empty($licensestatus)) {
                    return;
                }

                if (isset($licensedata->license) && ! empty($licensedata->license)) {
                    // Update license status.
                    set_config(
                        'edd_' . $this->pluginslug . '_license_status',
                        $licensestatus,
                        'format_edwiservideoformat'
                    );
                }

                $this->set_response_data($licensestatus, $this->pluginslug, true);
                return self::$responsedata;
            }
        } else {
            $licensestatus = get_config('format_edwiservideoformat', 'edd_' . $this->pluginslug . '_license_status');

            $this->set_response_data($licensestatus, $this->pluginslug);
            return self::$responsedata;
        }
    }

    /**
     * Set response data to plugin config
     * @param string  $licensestatus License status
     * @param string  $pluginslug    Plugin slug
     * @param boolean $settransient  Transient data
     */
    public function set_response_data($licensestatus, $pluginslug, $settransient = false) {
        if ($licensestatus == 'valid') {
            self::$responsedata = 'available';
        } else if ($licensestatus == 'expired') {
            self::$responsedata = 'available';
        } else {
            self::$responsedata  = 'unavailable';
        }

        if ($settransient) {
            // Set license transient.
            set_config(
                'wdm_' . $pluginslug . '_license_trans',
                json_encode([$licensestatus, time() + (60 * 60 * 24)]),
                'format_edwiservideoformat'
            );
        }
    }

    /**
     * This function is used to get list of sites where license key is already activated.
     *
     * @return string  list of site
     */
    public function get_site_list() {
        global $CFG;

        $sites = get_config('format_edwiservideoformat', 'wdm_' . $this->pluginslug . '_license_key_sites');
        $max = get_config('format_edwiservideoformat', 'wdm_' . $this->pluginslug . '_license_max_site');

        $sites = json_decode($sites, true);

        $cursite    = $CFG->wwwroot;
        $cursite    = preg_replace('#^https?://#', '', $cursite);

        $sitecount  = 0;
        $activesite = "";

        if (!empty($sites) || $sites != "") {
            foreach ($sites as $key) {
                foreach ($key as $value) {
                    $value = rtrim($value, "/");

                    if (strcasecmp($value, $cursite) != 0) {
                        $activesite .= "<li>" . $value . "</li>";
                        $sitecount++;
                    }
                }
            }
        }

        if ($sitecount >= $max) {
            return $activesite;
        } else {
            return "";
        }
    }

    /**
     * Handler for user add/remove
     * @param  [type] $api           Api name
     * @param  array  $licensedusers Licensed users array
     * @param  string $site          Site name
     * @return mixed                 Response from server
     */
    public function handle_users_api($api, $licensedusers = [], $site = '') {
        global $CFG;
        $pluginslug = $this->pluginslug;
        $licensekey = get_config('format_edwiservideoformat', 'edd_' . $pluginslug . '_license_key');
        $status = get_config('format_edwiservideoformat', 'edd_' . $pluginslug . '_license_status');
        if ($site == '') {
            $site = $CFG->wwwroot;
        }
        if ($licensekey && $status == 'valid') {
            $fields = [
                'key' => $licensekey,
                'site' => $site,
            ];
            if (!empty($licensedusers)) {
                $licensedusers = array_values($licensedusers);
                for ($i = 0; $i < count($licensedusers); $i++) {
                    $fields["users[$i]"] = $licensedusers[$i]->user;
                }
            } else {
                $fields["users[0]"] = '';
            }
            $curl = new \curl();
            $curl->setopt([
                'CURLOPT_ENCODING' => '',
                'CURLOPT_MAXREDIRS' => 10,
                'CURLOPT_TIMEOUT' => 30,
                'CURLOPT_HTTP_VERSION' => CURL_HTTP_VERSION_1_1,
            ]);
            // Send the request & save response to $resp.
            $resp = $curl->post("https://edwiser.org/wp-json/wdm-eddc/v1/potential-users/$api", $fields);
            return $resp;
        }
        return false;
    }

    /**
     * Get licensed users from api call
     * @return array Users list
     */
    public function edd_get_users_from_api() {
        global $CFG;
        $pluginslug = $this->pluginslug;
        $licensekey = get_config('format_edwiservideoformat', 'edd_' . $pluginslug . '_license_key');
        $status = get_config('format_edwiservideoformat', 'edd_' . $pluginslug . '_license_status');
        if ($licensekey && $status == 'valid') {
            $site = parse_url($CFG->wwwroot, PHP_URL_HOST) . '' . parse_url($CFG->wwwroot, PHP_URL_PATH);
            $curl = new \curl();
            $curl->setopt([
                'CURLOPT_ENCODING' => '',
                'CURLOPT_MAXREDIRS' => 10,
                'CURLOPT_TIMEOUT' => 30,
                'CURLOPT_HTTP_VERSION' => CURL_HTTP_VERSION_1_1,
            ]);
            $curl->setHeader('Content-Type: application/json');
            $url = "https://edwiser.org/wp-json/wdm-eddc/v1/potential-users/get?key=" . $licensekey . "&site=" . $site;
            // Send the request & save response to $resp.
            $resp = $curl->get($url);
            return json_decode($resp);
        }
    }
}

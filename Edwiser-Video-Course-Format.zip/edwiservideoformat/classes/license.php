<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * License management page
 *
 * @package   format_edwiservideoformat
 * @copyright Copyright (c) 2024 WisdmLabs. (http://www.wisdmlabs.com)
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once('../../../../config.php');
require_once($CFG->libdir . '/adminlib.php');
require_once('license_controller.php');

global $PAGE, $CFG, $OUTPUT;
admin_externalpage_setup('format_edwiservideoformat_licensestatus');

$systemcontext = context_system::instance();
$PAGE->set_context($systemcontext);
$PAGE->set_pagelayout('admin');
$title = get_string('licensestatus', 'format_edwiservideoformat');
$PAGE->set_title($title);
$PAGE->set_heading(get_string('licensestatus', 'format_edwiservideoformat'));
$PAGE->set_url($CFG->wwwroot . "/course/format/edwiservideoformat/classes/license.php");

require_capability('format/edwiservideoformat:can_manage_license', $systemcontext);

$pluginslug = 'edwiser-video-course-format';
$lcontroller = new \format_edwiservideoformat\edwiservideoformat_license_controller();
$lcontroller->add_data();
$licensekey = get_config('format_edwiservideoformat', 'edd_' . $pluginslug . '_license_key');

// Get License Status.
$lastaction = optional_param('lastaction', false, PARAM_ALPHA);
$status = get_config('format_edwiservideoformat', 'edd_' . $pluginslug . '_license_status');

// Get renew link.
$renewlink = get_config('format_edwiservideoformat', 'wdm_' . $pluginslug . '_product_site');

$cfglicensekey = get_config('format_edwiservideoformat', 'licensekey');
$licensekeyactivate = get_config('format_edwiservideoformat', 'licensekeyactivate');
$licensekeydeactivate = get_config('format_edwiservideoformat', 'licensekeydeactivate');

// Build notification data based on last action.
$notification = null;
if ($cfglicensekey == 'empty') {
    $notification = [
        'type' => 'danger',
        'issuccess' => false,
        'heading' => get_string('error', 'format_edwiservideoformat'),
        'message' => get_string('enterlicensekey', 'format_edwiservideoformat'),
    ];
}
if ($lastaction !== false && $lastaction == 'valid' && optional_param('licensekeyactivate', false, PARAM_ALPHA) != false) {
    $notification = [
        'type' => 'success',
        'issuccess' => true,
        'heading' => get_string('success', 'format_edwiservideoformat'),
        'message' => get_string('licensekeyactivated', 'format_edwiservideoformat'),
    ];
} else if ($lastaction !== false && $lastaction == 'expired') {
    $notification = [
        'type' => 'danger',
        'issuccess' => false,
        'heading' => get_string('alert', 'format_edwiservideoformat'),
        'message' => get_string('licensekeyhasexpired', 'format_edwiservideoformat'),
    ];
} else if ($lastaction !== false && $lastaction == 'disabled') {
    $notification = [
        'type' => 'danger',
        'issuccess' => false,
        'heading' => get_string('alert', 'format_edwiservideoformat'),
        'message' => get_string('licensekeyisdisabled', 'format_edwiservideoformat'),
    ];
} else if ($lastaction == 'invalid') {
    $notification = [
        'type' => 'danger',
        'issuccess' => false,
        'heading' => get_string('alert', 'format_edwiservideoformat'),
        'message' => get_string('entervalidlicensekey', 'format_edwiservideoformat'),
    ];
} else if ($lastaction == 'noactivationsleft') {
    $notification = [
        'type' => 'danger',
        'issuccess' => false,
        'heading' => get_string('alert', 'format_edwiservideoformat'),
        'message' => get_string('nolicenselimitleft', 'format_edwiservideoformat'),
    ];
} else if ($lastaction == 'site_inactive') {
    $notification = [
        'type' => 'danger',
        'issuccess' => false,
        'heading' => get_string('alert', 'format_edwiservideoformat'),
        'message' => get_string('siteinactive', 'format_edwiservideoformat'),
    ];
} else if ($lastaction == 'deactivated') {
    $notification = [
        'type' => 'danger',
        'issuccess' => false,
        'heading' => get_string('alert', 'format_edwiservideoformat'),
        'message' => get_string('licensekeydeactivated', 'format_edwiservideoformat'),
    ];
} else if (
    $lastaction == 'no_response' ||
    (optional_param('licensekeydeactivate', false, PARAM_ALPHA) != false && $lastaction == 'valid')
) {
    $notification = [
        'type' => 'danger',
        'issuccess' => false,
        'heading' => get_string('alert', 'format_edwiservideoformat'),
        'message' => get_string('noresponsereceived', 'format_edwiservideoformat'),
    ];
}

// Remove config vars.
unset_config('licensekey', 'format_edwiservideoformat');
unset_config('licensekeyactivate', 'format_edwiservideoformat');
unset_config('licensekeydeactivate', 'format_edwiservideoformat');

// Determine status display.
$statusvalid = ($status !== false && $status == 'valid');
$statusexpired = ($status == 'expired');

if ($statusvalid) {
    $statustext = get_string('active', 'format_edwiservideoformat');
    $statusclass = 'green';
} else if ($statusexpired) {
    $statustext = get_string('expired', 'format_edwiservideoformat');
    $statusclass = 'red';
} else if ($status == 'no_activations_left') {
    $statustext = get_string('no_activations_left', 'format_edwiservideoformat');
    $statusclass = 'red';
} else {
    $statustext = get_string('notactive', 'format_edwiservideoformat');
    $statusclass = 'red';
}

// Build template context.
$templatedata = [
    'notification' => $notification,
    'sesskey' => sesskey(),
    'pluginslug' => $pluginslug,
    'licensekey' => $licensekey ?: '',
    'statusvalid' => $statusvalid,
    'readonly' => ($statusvalid || $statusexpired),
    'statustext' => $statustext,
    'statusclass' => $statusclass,
    'showdeactivate' => ($statusvalid || $statusexpired),
    'showactivate' => (!$statusvalid && !$statusexpired),
    'showrenew' => $statusexpired,
    'renewlink' => $renewlink ?: 'https://edwiser.org/my-account/',
];

// Handle form submission redirect.
$onlicensepage = optional_param('onEdwiserVideoFormatLicensePage', 0, PARAM_INT);
if ($onlicensepage) {
    confirm_sesskey();
    $url = new moodle_url('/course/format/edwiservideoformat/classes/license.php', ['lastaction' => $status,
        'licensekeyactivate' => $licensekeyactivate,
        'licensekeydeactivate' => $licensekeydeactivate]);
    redirect($url->out());
}

echo $OUTPUT->header();
echo $OUTPUT->render_from_template('format_edwiservideoformat/license', $templatedata);
echo $OUTPUT->footer();

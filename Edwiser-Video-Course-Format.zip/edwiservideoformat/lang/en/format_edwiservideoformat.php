<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Language strings for format_edwiservideoformat (English).
 *
 * @package   format_edwiservideoformat
 * @copyright (c) 2023 WisdmLabs (https://wisdmlabs.com/) <support@wisdmlabs.com>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['activatelicense'] = 'Activate License';
$string['active'] = 'Active';
$string['activitiescompleted'] = 'activities completed';
$string['activitiesremaining'] = 'activities remaining';
$string['activitycompleted'] = 'activity completed';
$string['activitydisplaymode'] = 'Activity Display Mode';
$string['activitydisplaymode_desc'] = 'Choose how activities are displayed in the video course format';
$string['activitydisplaymode_help'] = 'When set to "Show activities in \'Edwiser Video Format\' view", activities will open in an iframe within the course page. When set to "Show activities in Moodle view", activities will redirect to their dedicated activity pages.';
$string['activityremaining'] = 'activity remaining';
$string['activitystart'] = 'Start Activity';
$string['addnewsection'] = 'Add new section';
$string['alert'] = 'Alert!';
$string['allactivitiescompleted'] = 'All activities completed';
$string['auto'] = 'auto';
$string['bottom'] = 'bottom';
$string['cachedef_redirected'] = 'Edwiser Video Format redirected activity session cache';
$string['center'] = 'center';
$string['contain'] = 'contain';
$string['coursedisplay'] = 'Course display';
$string['coursedisplay_desc'] = 'This defines how the course is displayed on the course page';
$string['coursedisplay_multi'] = 'Show all sections on one page';
$string['coursedisplay_single'] = 'Show one section per page';
$string['cover'] = 'cover';
$string['currentsection'] = 'This section';
$string['currentstatus'] = 'Current Status';
$string['deactivatelicense'] = 'Deactivate License';
$string['editsection'] = 'Edit section';
$string['editsectionname'] = 'Edit section name';
$string['edw_format_hd_bgpos'] = 'Course header background image position';
$string['edw_format_hd_bgpos_help'] = 'Choose background image position';
$string['edw_format_hd_bgsize'] = 'Course header background image size';
$string['edw_format_hd_bgsize_help'] = 'Select Course header background image size';
$string['edwiservideoactivity_desc'] = 'Create a new Edwiser Video Activity.';
$string['edwiservideoformat:can_manage_license'] = 'Manage Edwiser Video Course Format license';
$string['edwiservideoformat_courseimage_filemanager'] = 'Course Header Image';
$string['edwiservideoformat_courseimage_filemanager_help'] = 'This image will be displayed as a background in the course header. <strong>Recommended image size 1272x288.</strong>';
$string['edwiservideoformatlicenseactivation'] = 'Edwiser Video Format License Activation';
$string['enterlicensekey'] = 'Enter your license key';
$string['enterlicensekeyplaceholder'] = 'Enter license key...';
$string['entervalidlicensekey'] = 'Please enter a valid license key!';
$string['error'] = 'Error';
$string['error_customfield_creation'] = 'Error: Custom field creation failed: {$a}';
$string['expired'] = 'Expired';
$string['general_settings'] = 'General Settings';
$string['headeroverlayopacity'] = 'Change the header overlay opacity';
$string['headeroverlayopacity_help'] = 'The default value is already set to \'100\'. To adjust opacity, please enter a value between 0 and 100';
$string['hiddensections'] = 'Hidden sections';
$string['hiddensections_desc'] = 'How hidden sections are displayed to students';
$string['hiddensections_help'] = 'Hidden sections can be displayed to students as \'not available\' on the course page, or kept completely hidden.';
$string['hiddensectionscollapsed'] = 'Hidden sections are shown collapsed';
$string['hiddensectionsinvisible'] = 'Hidden sections are completely invisible';
$string['hidefromothers'] = 'Hide';
$string['left'] = 'left';
$string['licenseactivationrequired'] = '<strong>Alert!</strong> Edwiser video course format license is not activated, please <strong>activate</strong> the license <a class="text-primary" href="{$a}">here</a>.';
$string['licenseinvalid'] = 'License is invalid or inactive';
$string['licensekey'] = 'License Key';
$string['licensekeyactivated'] = 'Edwiser Video Format license is active.';
$string['licensekeydeactivated'] = 'License key deactivated successfully!';
$string['licensekeyhasexpired'] = 'License key has expired!';
$string['licensekeyisdisabled'] = 'License key is disabled!';
$string['licensenotactive'] = 'Your Edwiser Video Format license is not active. Please contact your administrator.';
$string['licensenotactiveadmin'] = 'Edwiser Video Format license is not active. Please activate your license in the plugin settings.';
$string['licensesetting'] = 'Edwiser Video Course Format License Setting';
$string['licensestatus'] = 'License Status';
$string['licensevalid'] = 'License is valid and active';
$string['modactivitynotfound'] = 'mod_edwiservideoactivity Plugin missing or not installed';
$string['moreactivities'] = 'More activities...';
$string['moreactivities_desc'] = 'Add other activities and resources';
$string['newsectionname'] = 'New name for section {$a}';
$string['no_activations_left'] = 'Limit exceeded';
$string['nolicenselimitleft'] = 'Maximum activation limit reached, No activations left. To reset your activition limit go to <a href="https://edwiser.org/my-account/" target="_blank">My Account.</a>';
$string['noresponsereceived'] = 'No response received from server!';
$string['notactive'] = 'Not Active';
$string['outof'] = 'out of';
$string['page-course-view-edwiservideoformat'] = 'Any course main page in Edwiser Video format';
$string['page-course-view-edwiservideoformat-x'] = 'Any course page in Edwiser Video format';
$string['plugin_description'] = 'Courses are structured as a series of video lessons, providing a clear, streamlined learning path similar to popular online platforms. Ideal for video-first learning experiences.';
$string['pluginname'] = 'Edwiser Video Format';
$string['privacy:metadata'] = 'The Edwiser Video Course Format plugin stores user preferences and transmits data to edwiser.org for license validation.';
$string['privacy:metadata:external'] = 'License and user data is sent to edwiser.org for license validation and user management.';
$string['privacy:metadata:external:licensekey'] = 'The plugin license key.';
$string['privacy:metadata:external:siteurl'] = 'The site URL is sent to identify the Moodle installation.';
$string['privacy:metadata:external:users'] = 'User information is sent for license-based user management.';
$string['progress'] = 'Progress';
$string['quiz_desc'] = 'Create a new Quiz activity.';
$string['renewlicense'] = 'Renew License';
$string['resumetoactivity'] = 'Resume';
$string['right'] = 'right';
$string['section0name'] = 'General';
$string['sectionname'] = 'Section';
$string['showactivitiesonactivitypage'] = 'Show activities in Moodle view';
$string['showactivitiesonsamepage'] = "Show activities in \u{2018}Edwiser Video Format\u{2019} view";
$string['showcoursedescription'] = 'Show course description';
$string['showcoursedescription_help'] = 'When enabled, the course description will be displayed on the course page.';
$string['showfromothers'] = 'Show';
$string['showless'] = 'Show less';
$string['showmore'] = 'Show more';
$string['siteinactive'] = 'Site is inactive!';
$string['startactivity'] = 'Start';
$string['success'] = 'Success';
$string['teachers'] = 'Teachers';
$string['top'] = 'top';

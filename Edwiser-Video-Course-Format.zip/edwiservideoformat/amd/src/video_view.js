// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Video view page initialization for Edwiser Video Format.
 *
 * Adds body class for video-active state and monitors iframes
 * with the 'edwembeded' class to inject a body class into their content.
 *
 * @module     format_edwiservideoformat/video_view
 * @copyright  2024 Edwiser
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

define([], function() {

    /**
     * Add class to iframe body content.
     * @param {HTMLIFrameElement} iframe The iframe element.
     */
    const addClassToIframe = function(iframe) {
        try {
            if (iframe.contentDocument && iframe.contentDocument.body) {
                iframe.contentDocument.body.classList.add('edwembeded');
            }
        } catch (e) {
            // Cross-origin iframe, silently ignore.
        }
    };

    /**
     * Initialize the video view page.
     */
    const init = function() {
        document.body.classList.add('edwiservideo-active');

        // Add class to existing edwembeded iframes after a short delay.
        setTimeout(function() {
            document.querySelectorAll('iframe.edwembeded').forEach(addClassToIframe);
        }, 1000);

        // Observe DOM for dynamically added iframes.
        var observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                Array.from(mutation.addedNodes).forEach(function(node) {
                    if (node.nodeName === 'IFRAME' && node.classList.contains('edwembeded')) {
                        node.addEventListener('load', function() {
                            addClassToIframe(node);
                        });
                    }
                });
            });
        });

        observer.observe(document.body, {childList: true, subtree: true});

        // Handle existing quiz iframe.
        var existing = document.getElementById('quiziframe');
        if (existing) {
            existing.addEventListener('load', function() {
                addClassToIframe(existing);
            });
            // If already loaded, trigger manually.
            try {
                if (existing.contentDocument && existing.contentDocument.readyState === 'complete') {
                    addClassToIframe(existing);
                }
            } catch (e) {
                // Cross-origin iframe, silently ignore.
            }
        }
    };

    return {
        init: init
    };
});

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Header replacement functionality for Edwiser Video Format.
 *
 * @module     format_edwiservideoformat/headerreplaces
 * @copyright  Edwiser
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

define(['jquery'], function($) {
    /**
     * Init method
     */
    function init() {
        $(document).ready(function() {
            var headercontent = $(".edwiservideoformat-header-wrapper").html();

            // The format renders a hidden .edwiservideoformat-header-wrapper that
            // also contains #page-header. We must only touch the VISIBLE theme header.
            var visibleHeader = $('#page-header').filter(function() {
                return $(this).closest('.edwiservideoformat-header-wrapper').length === 0;
            });

            // Preserve the original bulk edit button before replacing the header.
            var oldBulkButton = visibleHeader.find('.bulkEnable').detach();

            // Replace only the visible header with the custom design.
            visibleHeader.replaceWith(headercontent);

            // Locate the newly inserted visible header.
            var newHeader = $('#page-header').filter(function() {
                return $(this).closest('.edwiservideoformat-header-wrapper').length === 0;
            });

            // Re-attach the preserved bulk button to the new header.
            if (oldBulkButton.length > 0) {
                var targetContainer = newHeader.find('.align-self-end');
                if (targetContainer.length > 0) {
                    targetContainer.append(oldBulkButton);
                } else {
                    newHeader.append(oldBulkButton);
                }
            } else {
                // No original bulk button was present; check if the custom header
                // rendered one and initialize it.
                var newBulkButton = newHeader.find('.bulkEnable');
                if (newBulkButton.length > 0 && newBulkButton.attr('id')) {
                    require(['core_courseformat/local/content/bulkedittoggler'], function(component) {
                        component.init('#' + newBulkButton.attr('id'));
                    });
                }
            }
        });
    }

    // Must return the init function.
    return {
        init: init
    };
});
